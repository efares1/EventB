let m0_IsleAccess = {
	name = "m0_IsleAccess";
	refines = [];
	sees = [];
	variables = [];
	invariants = [];
	events = [{
		name = "INITIALISATION";
		refinements = [];
		parameters = [];
		guards = [];
		witness = [];
		action = []
	}
	; {
		name = "ML2BR";
		refinements = [];
		parameters = [];
		guards = [];
		witness = [];
		action = []
	}
	; {
		name = "BR2ML";
		refinements = [];
		parameters = [];
		guards = [];
		witness = [];
		action = []
	}
	]
}
