(*
machine m1_IsleCapacity refines m0_IsleAccess
sees cCapacity
variables
	cars
invariants
	@cars_ty cars ∈ ℤ
	@capacity  cars ∈ 0‥capacity
events
	event INITIALISATION extends INITIALISATION
	then
		@cars cars ≔ 0
	end
	event ML2BR extends ML2BR
	when 
		@capacity ¬cars=capacity
	then
		@cars cars ≔ cars+1
	end
	event BR2ML extends BR2ML
	when 
		@capacity cars − 1∈0 ‥ capacity
	then
		@cars cars ≔ cars−1
	end
end
*)
------- MODULE m1_IsleCapacity -------
EXTENDS Integers, TLAPS, cCapacity
VARIABLES
	event, cars
vars == <<event, cars>>
Inv_cars_ty == (cars \in Int)
Inv_capacity == (cars \in (0 .. capacity))

Invariant ==
	/\ Inv_cars_ty
	/\ Inv_capacity

Init == 
	/\ event = <<"INITIALISATION">>
	/\ <<cars>> = <<0>>
ML2BR  == event = <<"ML2BR">>
GRD_ML2BR ==
	/\ (\neg (cars = capacity))
ACT_ML2BR ==
	/\ <<cars'>> = <<(cars+1)>>
_ML2BR  ==
	/\ ML2BR'
	/\ GRD_ML2BR
	/\ ACT_ML2BR
BR2ML  == event = <<"BR2ML">>
GRD_BR2ML ==
	/\ ((cars - 1) \in (0 .. capacity))
ACT_BR2ML ==
	/\ <<cars'>> = <<(cars - 1)>>
_BR2ML  ==
	/\ BR2ML'
	/\ GRD_BR2ML
	/\ ACT_BR2ML

Next ==
	\/ _ML2BR
	\/ _BR2ML

Spec == Init /\ [][Next]_vars
THEOREM PO_Next_ML2BR_cars_ty == Invariant /\ _ML2BR => Inv_cars_ty'
PROOF
BY DEF Invariant, Inv_cars_ty, Inv_capacity, _ML2BR, GRD_ML2BR, ACT_ML2BR, ML2BR

THEOREM PO_Next_BR2ML_cars_ty == Invariant /\ _BR2ML => Inv_cars_ty'
PROOF
BY DEF Invariant, Inv_cars_ty, Inv_capacity, _BR2ML, GRD_BR2ML, ACT_BR2ML, BR2ML

THEOREM PO_Init_cars_ty == Init => Inv_cars_ty
PROOF
BY DEF Init, Inv_cars_ty

THEOREM PO_Next_cars_ty == Invariant /\ Next => Inv_cars_ty'
PROOF
BY THEOREM PO_Next_ML2BR_cars_ty, THEOREM PO_Next_BR2ML_cars_ty DEF Next

THEOREM PO_Next_ML2BR_capacity == Invariant /\ Inv_cars_ty' /\ _ML2BR => Inv_capacity'
PROOF
BY DEF Invariant, Inv_cars_ty, Inv_capacity, _ML2BR, GRD_ML2BR, ACT_ML2BR, ML2BR

THEOREM PO_Next_BR2ML_capacity == Invariant /\ Inv_cars_ty' /\ _BR2ML => Inv_capacity'
PROOF
BY DEF Invariant, Inv_cars_ty, Inv_capacity, _BR2ML, GRD_BR2ML, ACT_BR2ML, BR2ML

THEOREM PO_Init_capacity == Init => Inv_capacity
PROOF
BY DEF Init, Inv_capacity

THEOREM PO_Next_capacity == Invariant /\ Next /\ Inv_cars_ty' => Inv_capacity'
PROOF
BY THEOREM PO_Next_ML2BR_capacity, THEOREM PO_Next_BR2ML_capacity DEF Next


THEOREM InvariantIsPreserved == Invariant /\ Next => Invariant'
PROOF
BY THEOREM PO_Next_cars_ty, THEOREM PO_Next_capacity DEF Invariant

THEOREM NoDeadlock == Invariant => 
	\/ GRD_ML2BR
	\/ GRD_BR2ML
PROOF
	BY DEF GRD_ML2BR,GRD_BR2ML, Invariant,Inv_cars_ty,Inv_capacity
========================================
