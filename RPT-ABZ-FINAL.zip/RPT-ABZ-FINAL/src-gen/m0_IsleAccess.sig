process m0_IsleAccess = (? integer cmd; )
(|
	  INITIALISATION ^= when cmd = E_INITIALISATION 
	| ML2BR ^= when cmd = E_ML2BR 
	| BR2ML ^= when cmd = E_BR2ML 
	| cmd ^= ^INITIALISATION ^+ ^ML2BR ^+ ^BR2ML
|) where event INITIALISATION; event ML2BR; event BR2ML,
	constant integer E_INITIALISATION = 0;
	constant integer E_ML2BR = 1;
	constant integer E_BR2ML = 2
   end;
