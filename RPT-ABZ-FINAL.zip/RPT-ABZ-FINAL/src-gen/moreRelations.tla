---- MODULE moreRelations ----
partition(E,PE) == UNION(PE) = E
====