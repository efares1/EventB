process m4_Sensors = (? integer cmd; )
(|
	  INITIALISATION ^= when cmd = E_INITIALISATION 
	| ML2BR ^= when cmd = E_ML2BR when  ml_out_10 = TRUE when  il_out_10=TRUE⇒il_tl=green
	| BR2ML ^= when cmd = E_BR2ML when  ml_in_10 = TRUE when  ml_out_10=TRUE⇒{TRUE ↦ red,FALSE ↦ ml_tl}(bool(ml_tl=green∧¬(exiting − 1=0∧¬cars − 1=capacity)))=green when  il_out_10=TRUE⇒{TRUE ↦ red,FALSE ↦ il_tl}(bool(il_tl=green∧¬entering=0))=green
	| BR2IL ^= when cmd = E_BR2IL when  il_in_10 = TRUE when  ml_out_10=TRUE⇒{TRUE ↦ red,FALSE ↦ ml_tl}(bool(ml_tl=green∧¬(exiting=0∧¬cars=capacity)))=green when  il_out_10=TRUE⇒{TRUE ↦ red,FALSE ↦ il_tl}(bool(il_tl=green∧¬entering − 1=0))=green
	| IL2BR ^= when cmd = E_IL2BR when    islecars − 1≥0 when  il_out_10 = TRUE when  ml_out_10=TRUE⇒ml_tl=green
	| ml_green ^= when cmd = E_ml_green 
	| il_green ^= when cmd = E_il_green 
	| ML2BR_sensor ^= when cmd = E_ML2BR_sensor when  ml_out_10 = FALSE when   ml_tl =  green
	| IL2BR_sensor ^= when cmd = E_IL2BR_sensor when  il_out_10 = FALSE when   il_tl =  green
	| BR2ML_sensor ^= when cmd = E_BR2ML_sensor when  ml_in_10 = FALSE
	| BR2IL_sensor ^= when cmd = E_BR2IL_sensor when  il_in_10 = FALSE
	| cmd ^= ^INITIALISATION ^+ ^ML2BR ^+ ^BR2ML ^+ ^BR2IL ^+ ^IL2BR ^+ ^ml_green ^+ ^il_green ^+ ^ML2BR_sensor ^+ ^IL2BR_sensor ^+ ^BR2ML_sensor ^+ ^BR2IL_sensor
|) where event INITIALISATION; event ML2BR; event BR2ML; event BR2IL; event IL2BR; event ml_green; event il_green; event ML2BR_sensor; event IL2BR_sensor; event BR2ML_sensor; event BR2IL_sensor,
	constant integer E_INITIALISATION = 0;
	constant integer E_ML2BR = 1;
	constant integer E_BR2ML = 2;
	constant integer E_BR2IL = 3;
	constant integer E_IL2BR = 4;
	constant integer E_ml_green = 5;
	constant integer E_il_green = 6;
	constant integer E_ML2BR_sensor = 7;
	constant integer E_IL2BR_sensor = 8;
	constant integer E_BR2ML_sensor = 9;
	constant integer E_BR2IL_sensor = 10
   end;
