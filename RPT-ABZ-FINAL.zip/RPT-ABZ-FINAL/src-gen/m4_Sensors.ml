let m4_Sensors = {
	name = "m4_Sensors";
	refines = [m3_TrafficLights];
	sees = [cColor; cCapacity];
	variables = ["entering"; "islecars"; "exiting"; "cars"; "ml_tl"; "il_tl"; "ml_out_10"; "il_out_10"; "ml_in_10"; "il_in_10"];
	invariants = [{name = "ml_out_10_ty"; predicate =  ml_out_10 ∈ BOOL}
	; {name = "ml_out_10_ok"; predicate =  ml_out_10=TRUE⇒ml_tl=green}
	; {name = "il_out_10_ty"; predicate =  il_out_10 ∈ BOOL}
	; {name = "il_out_10_ok"; predicate =  il_out_10=TRUE⇒il_tl=green}
	; {name = "ml_in_10_ty"; predicate =  ml_in_10 ∈ BOOL}
	; {name = "il_in_10_ty"; predicate =  il_in_10 ∈ BOOL}
	];
	events = [{
		name = "INITIALISATION";
		refinements = [];
		parameters = [];
		guards = [];
		witness = [];
		action = [{name = "ml_out_10"; action = {left = ["ml_out_10"]; right = [ FALSE]}
		}
		;{name = "il_out_10"; action = {left = ["il_out_10"]; right = [ FALSE]}
		}
		;{name = "ml_in_10"; action = {left = ["ml_in_10"]; right = [ FALSE]}
		}
		;{name = "il_in_10"; action = {left = ["il_in_10"]; right = [ FALSE]}
		}
		]
	}
	; {
		name = "ML2BR";
		refinements = [ML2BR];
		parameters = [];
		guards = [{name = "ml_out_10_ok"; predicate =  ml_out_10 = TRUE}
		;{name = "IL2BR_il_tl_ok"; predicate =  il_out_10=TRUE⇒il_tl=green}
		];
		witness = [];
		action = [{name = "ml_out_10_ko"; action = {left = ["ml_out_10"]; right = [ FALSE]}
		}
		;{name = "ml_tl_ko"; action = {left = ["ml_tl"]; right = [   red]}
		}
		;{name = "entering"; action = {left = ["entering"]; right = [   entering+1]}
		}
		]
	}
	; {
		name = "BR2ML";
		refinements = [BR2ML];
		parameters = [];
		guards = [{name = "ml_in_10_ok"; predicate =  ml_in_10 = TRUE}
		;{name = "ML2BR_ml_tl_ok"; predicate =  ml_out_10=TRUE⇒{TRUE ↦ red,FALSE ↦ ml_tl}(bool(ml_tl=green∧¬(exiting − 1=0∧¬cars − 1=capacity)))=green}
		;{name = "IL2BR_il_tl_ok"; predicate =  il_out_10=TRUE⇒{TRUE ↦ red,FALSE ↦ il_tl}(bool(il_tl=green∧¬entering=0))=green}
		];
		witness = [];
		action = [{name = "ml_in_10_ko"; action = {left = ["ml_in_10"]; right = [ FALSE]}
		}
		;{name = "ml_tl_ko"; action = {left = ["ml_tl"]; right = [  {TRUE ↦ red,FALSE ↦ ml_tl}(bool(ml_tl=green∧¬(exiting − 1=0∧¬cars − 1=capacity)))]}
		}
		;{name = "il_tl_ko"; action = {left = ["il_tl"]; right = [  {TRUE ↦ red,FALSE ↦ il_tl}(bool(il_tl=green∧¬entering=0))]}
		}
		]
	}
	; {
		name = "BR2IL";
		refinements = [BR2IL];
		parameters = [];
		guards = [{name = "il_in_10_ok"; predicate =  il_in_10 = TRUE}
		;{name = "ML2BR_ml_tl_ok"; predicate =  ml_out_10=TRUE⇒{TRUE ↦ red,FALSE ↦ ml_tl}(bool(ml_tl=green∧¬(exiting=0∧¬cars=capacity)))=green}
		;{name = "IL2BR_il_tl_ok"; predicate =  il_out_10=TRUE⇒{TRUE ↦ red,FALSE ↦ il_tl}(bool(il_tl=green∧¬entering − 1=0))=green}
		];
		witness = [];
		action = [{name = "il_in_10_ko"; action = {left = ["il_in_10"]; right = [ FALSE]}
		}
		;{name = "ml_tl_ko"; action = {left = ["ml_tl"]; right = [  {TRUE ↦ red,FALSE ↦ ml_tl}(bool(ml_tl=green∧¬(exiting=0∧¬cars=capacity)))]}
		}
		;{name = "il_tl_ko"; action = {left = ["il_tl"]; right = [  {TRUE ↦ red,FALSE ↦ il_tl}(bool(il_tl=green∧¬entering − 1=0))]}
		}
		]
	}
	; {
		name = "IL2BR";
		refinements = [IL2BR];
		parameters = [];
		guards = [{name = "stay_ctr"; predicate =    islecars − 1≥0}
		;{name = "il_out_10_ok"; predicate =  il_out_10 = TRUE}
		;{name = "ML2BR_ml_tl_ok"; predicate =  ml_out_10=TRUE⇒ml_tl=green}
		];
		witness = [];
		action = [{name = "il_out_10_ko"; action = {left = ["il_out_10"]; right = [ FALSE]}
		}
		;{name = "il_tl_ko"; action = {left = ["il_tl"]; right = [   red]}
		}
		;{name = "exiting"; action = {left = ["exiting"]; right = [   exiting+1]}
		}
		;{name = "islecars"; action = {left = ["islecars"]; right = [   islecars−1]}
		}
		]
	}
	; {
		name = "ml_green";
		refinements = [];
		parameters = [];
		guards = [];
		witness = [];
		action = [{name = "il_out_10_ko"; action = {left = ["il_out_10"]; right = [ FALSE]}
		}
		]
	}
	; {
		name = "il_green";
		refinements = [];
		parameters = [];
		guards = [];
		witness = [];
		action = [{name = "ml_out_10_ko"; action = {left = ["ml_out_10"]; right = [ FALSE]}
		}
		]
	}
	; {
		name = "ML2BR_sensor";
		refinements = [];
		parameters = [];
		guards = [{name = "ml_out_10_ko"; predicate =  ml_out_10 = FALSE}
		;{name = "ml_tl_ok"; predicate =   ml_tl =  green}
		];
		witness = [];
		action = [{name = "ml_out_10"; action = {left = ["ml_out_10"]; right = [ TRUE]}
		}
		]
	}
	; {
		name = "IL2BR_sensor";
		refinements = [];
		parameters = [];
		guards = [{name = "il_out_10_ko"; predicate =  il_out_10 = FALSE}
		;{name = "il_tl_ok"; predicate =   il_tl =  green}
		];
		witness = [];
		action = [{name = "il_out_10"; action = {left = ["il_out_10"]; right = [ TRUE]}
		}
		]
	}
	; {
		name = "BR2ML_sensor";
		refinements = [];
		parameters = [];
		guards = [{name = "ml_in_10_ko"; predicate =  ml_in_10 = FALSE}
		];
		witness = [];
		action = [{name = "ml_in_10"; action = {left = ["ml_in_10"]; right = [ TRUE]}
		}
		]
	}
	; {
		name = "BR2IL_sensor";
		refinements = [];
		parameters = [];
		guards = [{name = "il_in_10_ko"; predicate =  il_in_10 = FALSE}
		];
		witness = [];
		action = [{name = "il_in_10"; action = {left = ["il_in_10"]; right = [ TRUE]}
		}
		]
	}
	]
}
