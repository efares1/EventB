---- MODULE Sequences ----

====