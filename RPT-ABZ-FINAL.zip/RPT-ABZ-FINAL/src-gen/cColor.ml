let  cColor = {
	name = "cColor";
	extends = [];
	sets = ["COLOR"];
	constants = ["red"; "green"];
	axioms = [{name = "color"; predicate = " partition(COLOR, {red},{green})"}]
}
