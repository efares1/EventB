---- MODULE Naturals ----
CONSTANTS Nat
====