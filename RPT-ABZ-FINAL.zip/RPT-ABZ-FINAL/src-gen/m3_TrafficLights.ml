let m3_TrafficLights = {
	name = "m3_TrafficLights";
	refines = [m2_BridgeToIsle];
	sees = [cColor; cCapacity];
	variables = ["entering"; "islecars"; "exiting"; "cars"; "ml_tl"; "il_tl"];
	invariants = [{name = "ml_tl_ty"; predicate =  ml_tl ∈ COLOR}
	; {name = "ml_tl_ok"; predicate =  ml_tl=green⇒exiting=0∧¬cars=capacity}
	; {name = "il_tl_ty"; predicate =  il_tl ∈ COLOR}
	; {name = "il_tl_ok"; predicate =  il_tl=green⇒entering=0}
	; {name = "il_tl_ml_tl_excl"; predicate =  il_tl =  red ∨ ml_tl =  red}
	];
	events = [{
		name = "INITIALISATION";
		refinements = [];
		parameters = [];
		guards = [];
		witness = [];
		action = [{name = "ml_tl"; action = {left = ["ml_tl"]; right = [  red]}
		}
		;{name = "il_tl"; action = {left = ["il_tl"]; right = [  red]}
		}
		]
	}
	; {
		name = "ML2BR";
		refinements = [ML2BR];
		parameters = [];
		guards = [{name = "ml_tl_ok"; predicate =  ml_tl =  green}
		];
		witness = [];
		action = [{name = "ml_tl_ko"; action = {left = ["ml_tl"]; right = [  red]}
		}
		;{name = "entering"; action = {left = ["entering"]; right = [  entering+1]}
		}
		]
	}
	; {
		name = "BR2ML";
		refinements = [];
		parameters = [];
		guards = [];
		witness = [];
		action = [{name = "ml_tl_ko"; action = {left = ["ml_tl"]; right = [ {TRUE ↦ red,FALSE ↦ ml_tl}(bool(ml_tl=green∧¬(exiting − 1=0∧¬cars − 1=capacity)))]}
		}
		;{name = "il_tl_ko"; action = {left = ["il_tl"]; right = [ {TRUE ↦ red,FALSE ↦ il_tl}(bool(il_tl=green∧¬entering=0))]}
		}
		]
	}
	; {
		name = "BR2IL";
		refinements = [];
		parameters = [];
		guards = [];
		witness = [];
		action = [{name = "ml_tl_ko"; action = {left = ["ml_tl"]; right = [ {TRUE ↦ red,FALSE ↦ ml_tl}(bool(ml_tl=green∧¬(exiting=0∧¬cars=capacity)))]}
		}
		;{name = "il_tl_ko"; action = {left = ["il_tl"]; right = [ {TRUE ↦ red,FALSE ↦ il_tl}(bool(il_tl=green∧¬entering − 1=0))]}
		}
		]
	}
	; {
		name = "IL2BR";
		refinements = [IL2BR];
		parameters = [];
		guards = [{name = "stay_ctr"; predicate =   islecars − 1≥0}
		;{name = "il_tl_ok"; predicate =  il_tl =  green}
		];
		witness = [];
		action = [{name = "il_tl_ko"; action = {left = ["il_tl"]; right = [  red]}
		}
		;{name = "exiting"; action = {left = ["exiting"]; right = [  exiting+1]}
		}
		;{name = "islecars"; action = {left = ["islecars"]; right = [  islecars−1]}
		}
		]
	}
	; {
		name = "ml_green";
		refinements = [];
		parameters = [];
		guards = [{name = "ml_tl_ko"; predicate =  ml_tl =  red}
		;{name = "exclusivity"; predicate =   exiting=0}
		;{name = "capacity"; predicate =   ¬cars=capacity}
		];
		witness = [];
		action = [{name = "ml_tl"; action = {left = ["ml_tl"]; right = [  green]}
		}
		;{name = "il_tl"; action = {left = ["il_tl"]; right = [  red]}
		}
		]
	}
	; {
		name = "il_green";
		refinements = [];
		parameters = [];
		guards = [{name = "il_tl_ko"; predicate =  il_tl =  red}
		;{name = "exclusivity"; predicate =   entering=0}
		];
		witness = [];
		action = [{name = "il_tl"; action = {left = ["il_tl"]; right = [  green]}
		}
		;{name = "ml_tl"; action = {left = ["ml_tl"]; right = [  red]}
		}
		]
	}
	]
}
