---- MODULE TLAPS ----
ASSUME PTL == TRUE
ASSUME SimpleArithmetic == TRUE
======================