---- MODULE cColor ----
EXTENDS Naturals, Sequences, FiniteSets, moreRelations
CONSTANTS COLOR, red, green
(*  partition(COLOR, {red},{green}) *)
ASSUME color == partition(COLOR, { { red}, { green}})
====
