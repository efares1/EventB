(*
machine m3_TrafficLights refines m2_BridgeToIsle
sees cColor cCapacity
variables
	entering
	islecars
	exiting
	cars
	ml_tl
	il_tl
invariants
	@ml_tl_ty ml_tl ∈ COLOR
	@ml_tl_ok ml_tl=green⇒exiting=0∧¬cars=capacity
	@il_tl_ty il_tl ∈ COLOR
	@il_tl_ok il_tl=green⇒entering=0
	@il_tl_ml_tl_excl il_tl =  red ∨ ml_tl =  red
events
	event INITIALISATION extends INITIALISATION
	then
		@ml_tl ml_tl ≔  red
		@il_tl il_tl ≔  red
	end
	event ML2BR refines ML2BR
	when
		@ml_tl_ok ml_tl =  green
	then
		@ml_tl_ko ml_tl ≔  red
		@entering entering ≔  entering+1
	end
	event BR2ML extends BR2ML
	then
		@ml_tl_ko ml_tl ≔ {TRUE ↦ red,FALSE ↦ ml_tl}(bool(ml_tl=green∧¬(exiting − 1=0∧¬cars − 1=capacity)))
		@il_tl_ko il_tl ≔ {TRUE ↦ red,FALSE ↦ il_tl}(bool(il_tl=green∧¬entering=0))
	end
	event BR2IL extends BR2IL
	then
		@ml_tl_ko ml_tl ≔ {TRUE ↦ red,FALSE ↦ ml_tl}(bool(ml_tl=green∧¬(exiting=0∧¬cars=capacity)))
		@il_tl_ko il_tl ≔ {TRUE ↦ red,FALSE ↦ il_tl}(bool(il_tl=green∧¬entering − 1=0))
	end
	event IL2BR refines IL2BR
	when
		@stay_ctr  islecars − 1≥0
		@il_tl_ok il_tl =  green
	then
		@il_tl_ko il_tl ≔  red
		@exiting exiting ≔  exiting+1
		@islecars islecars ≔  islecars−1
	end
	event ml_green
	when
		@ml_tl_ko ml_tl =  red
		@exclusivity  exiting=0
		@capacity  ¬cars=capacity
	then
		@ml_tl ml_tl ≔  green
		@il_tl il_tl ≔  red
	end
	event il_green
	when
		@il_tl_ko il_tl =  red
		@exclusivity  entering=0
	then
		@il_tl il_tl ≔  green
		@ml_tl ml_tl ≔  red
	end
end
*)
------- MODULE m3_TrafficLights -------
EXTENDS Integers, TLAPS, cColor, cCapacity
VARIABLES
	event, entering, islecars, exiting, cars, ml_tl, il_tl
vars == <<event, entering, islecars, exiting, cars, ml_tl, il_tl>>
Inv_ml_tl_ty == (ml_tl \in COLOR)
Inv_ml_tl_ok == ((ml_tl = green) => (exiting = 0) /\  (\neg (cars = capacity)) )
Inv_il_tl_ty == (il_tl \in COLOR)
Inv_il_tl_ok == ((il_tl = green) => (entering = 0))
Inv_il_tl_ml_tl_excl == ((il_tl = red) \/  (ml_tl = red) )

Invariant ==
	/\ Inv_ml_tl_ty
	/\ Inv_ml_tl_ok
	/\ Inv_il_tl_ty
	/\ Inv_il_tl_ok
	/\ Inv_il_tl_ml_tl_excl

Init == 
	/\ event = <<"INITIALISATION">>
	/\ <<ml_tl>> = <<red>>
	/\ <<il_tl>> = <<red>>
ML2BR  == event = <<"ML2BR">>
GRD_ML2BR ==
	/\ (ml_tl = green)
ACT_ML2BR ==
	/\ <<ml_tl'>> = <<red>>
	/\ <<entering'>> = <<(entering+1)>>
	/\ UNCHANGED(<<islecars,exiting,cars,il_tl>>)
_ML2BR  ==
	/\ ML2BR'
	/\ GRD_ML2BR
	/\ ACT_ML2BR
BR2ML  == event = <<"BR2ML">>
GRD_BR2ML ==
ACT_BR2ML ==
	/\ <<ml_tl'>> = <<APPLY({ <<TRUE, red>>, <<FALSE, ml_tl>>})[(ml_tl = green) /\  (\neg ((exiting - 1) = 0) /\  (\neg ((cars - 1) = capacity)) ) ]>>
	/\ <<il_tl'>> = <<APPLY({ <<TRUE, red>>, <<FALSE, il_tl>>})[(il_tl = green) /\  (\neg (entering = 0)) ]>>
	/\ UNCHANGED(<<entering,islecars,exiting,cars>>)
_BR2ML  ==
	/\ BR2ML'
	/\ GRD_BR2ML
	/\ ACT_BR2ML
BR2IL  == event = <<"BR2IL">>
GRD_BR2IL ==
ACT_BR2IL ==
	/\ <<ml_tl'>> = <<APPLY({ <<TRUE, red>>, <<FALSE, ml_tl>>})[(ml_tl = green) /\  (\neg (exiting = 0) /\  (\neg (cars = capacity)) ) ]>>
	/\ <<il_tl'>> = <<APPLY({ <<TRUE, red>>, <<FALSE, il_tl>>})[(il_tl = green) /\  (\neg ((entering - 1) = 0)) ]>>
	/\ UNCHANGED(<<entering,islecars,exiting,cars>>)
_BR2IL  ==
	/\ BR2IL'
	/\ GRD_BR2IL
	/\ ACT_BR2IL
IL2BR  == event = <<"IL2BR">>
GRD_IL2BR ==
	/\ ((islecars - 1) >= 0)
	/\ (il_tl = green)
ACT_IL2BR ==
	/\ <<il_tl'>> = <<red>>
	/\ <<exiting'>> = <<(exiting+1)>>
	/\ <<islecars'>> = <<(islecars - 1)>>
	/\ UNCHANGED(<<entering,cars,ml_tl>>)
_IL2BR  ==
	/\ IL2BR'
	/\ GRD_IL2BR
	/\ ACT_IL2BR
ml_green  == event = <<"ml_green">>
GRD_ml_green ==
	/\ (ml_tl = red)
	/\ (exiting = 0)
	/\ (\neg (cars = capacity))
ACT_ml_green ==
	/\ <<ml_tl'>> = <<green>>
	/\ <<il_tl'>> = <<red>>
	/\ UNCHANGED(<<entering,islecars,exiting,cars>>)
_ml_green  ==
	/\ ml_green'
	/\ GRD_ml_green
	/\ ACT_ml_green
il_green  == event = <<"il_green">>
GRD_il_green ==
	/\ (il_tl = red)
	/\ (entering = 0)
ACT_il_green ==
	/\ <<il_tl'>> = <<green>>
	/\ <<ml_tl'>> = <<red>>
	/\ UNCHANGED(<<entering,islecars,exiting,cars>>)
_il_green  ==
	/\ il_green'
	/\ GRD_il_green
	/\ ACT_il_green

Next ==
	\/ _ML2BR
	\/ _BR2ML
	\/ _BR2IL
	\/ _IL2BR
	\/ _ml_green
	\/ _il_green

Spec == Init /\ [][Next]_vars
THEOREM PO_Next_ML2BR_ml_tl_ty == Invariant /\ _ML2BR => Inv_ml_tl_ty'
PROOF
BY DEF Invariant, Inv_ml_tl_ty, Inv_ml_tl_ok, Inv_il_tl_ty, Inv_il_tl_ok, Inv_il_tl_ml_tl_excl, _ML2BR, GRD_ML2BR, ACT_ML2BR, ML2BR

THEOREM PO_Next_BR2ML_ml_tl_ty == Invariant /\ _BR2ML => Inv_ml_tl_ty'
PROOF
BY DEF Invariant, Inv_ml_tl_ty, Inv_ml_tl_ok, Inv_il_tl_ty, Inv_il_tl_ok, Inv_il_tl_ml_tl_excl, _BR2ML, GRD_BR2ML, ACT_BR2ML, BR2ML

THEOREM PO_Next_BR2IL_ml_tl_ty == Invariant /\ _BR2IL => Inv_ml_tl_ty'
PROOF
BY DEF Invariant, Inv_ml_tl_ty, Inv_ml_tl_ok, Inv_il_tl_ty, Inv_il_tl_ok, Inv_il_tl_ml_tl_excl, _BR2IL, GRD_BR2IL, ACT_BR2IL, BR2IL

THEOREM PO_Next_IL2BR_ml_tl_ty == Invariant /\ _IL2BR => Inv_ml_tl_ty'
PROOF
BY DEF Invariant, Inv_ml_tl_ty, Inv_ml_tl_ok, Inv_il_tl_ty, Inv_il_tl_ok, Inv_il_tl_ml_tl_excl, _IL2BR, GRD_IL2BR, ACT_IL2BR, IL2BR

THEOREM PO_Next_ml_green_ml_tl_ty == Invariant /\ _ml_green => Inv_ml_tl_ty'
PROOF
BY DEF Invariant, Inv_ml_tl_ty, Inv_ml_tl_ok, Inv_il_tl_ty, Inv_il_tl_ok, Inv_il_tl_ml_tl_excl, _ml_green, GRD_ml_green, ACT_ml_green, ml_green

THEOREM PO_Next_il_green_ml_tl_ty == Invariant /\ _il_green => Inv_ml_tl_ty'
PROOF
BY DEF Invariant, Inv_ml_tl_ty, Inv_ml_tl_ok, Inv_il_tl_ty, Inv_il_tl_ok, Inv_il_tl_ml_tl_excl, _il_green, GRD_il_green, ACT_il_green, il_green

THEOREM PO_Init_ml_tl_ty == Init => Inv_ml_tl_ty
PROOF
BY DEF Init, Inv_ml_tl_ty

THEOREM PO_Next_ml_tl_ty == Invariant /\ Next => Inv_ml_tl_ty'
PROOF
BY THEOREM PO_Next_ML2BR_ml_tl_ty, THEOREM PO_Next_BR2ML_ml_tl_ty, THEOREM PO_Next_BR2IL_ml_tl_ty, THEOREM PO_Next_IL2BR_ml_tl_ty, THEOREM PO_Next_ml_green_ml_tl_ty, THEOREM PO_Next_il_green_ml_tl_ty DEF Next

THEOREM PO_Next_ML2BR_ml_tl_ok == Invariant /\ Inv_ml_tl_ty' /\ _ML2BR => Inv_ml_tl_ok'
PROOF
BY DEF Invariant, Inv_ml_tl_ty, Inv_ml_tl_ok, Inv_il_tl_ty, Inv_il_tl_ok, Inv_il_tl_ml_tl_excl, _ML2BR, GRD_ML2BR, ACT_ML2BR, ML2BR

THEOREM PO_Next_BR2ML_ml_tl_ok == Invariant /\ Inv_ml_tl_ty' /\ _BR2ML => Inv_ml_tl_ok'
PROOF
BY DEF Invariant, Inv_ml_tl_ty, Inv_ml_tl_ok, Inv_il_tl_ty, Inv_il_tl_ok, Inv_il_tl_ml_tl_excl, _BR2ML, GRD_BR2ML, ACT_BR2ML, BR2ML

THEOREM PO_Next_BR2IL_ml_tl_ok == Invariant /\ Inv_ml_tl_ty' /\ _BR2IL => Inv_ml_tl_ok'
PROOF
BY DEF Invariant, Inv_ml_tl_ty, Inv_ml_tl_ok, Inv_il_tl_ty, Inv_il_tl_ok, Inv_il_tl_ml_tl_excl, _BR2IL, GRD_BR2IL, ACT_BR2IL, BR2IL

THEOREM PO_Next_IL2BR_ml_tl_ok == Invariant /\ Inv_ml_tl_ty' /\ _IL2BR => Inv_ml_tl_ok'
PROOF
BY DEF Invariant, Inv_ml_tl_ty, Inv_ml_tl_ok, Inv_il_tl_ty, Inv_il_tl_ok, Inv_il_tl_ml_tl_excl, _IL2BR, GRD_IL2BR, ACT_IL2BR, IL2BR

THEOREM PO_Next_ml_green_ml_tl_ok == Invariant /\ Inv_ml_tl_ty' /\ _ml_green => Inv_ml_tl_ok'
PROOF
BY DEF Invariant, Inv_ml_tl_ty, Inv_ml_tl_ok, Inv_il_tl_ty, Inv_il_tl_ok, Inv_il_tl_ml_tl_excl, _ml_green, GRD_ml_green, ACT_ml_green, ml_green

THEOREM PO_Next_il_green_ml_tl_ok == Invariant /\ Inv_ml_tl_ty' /\ _il_green => Inv_ml_tl_ok'
PROOF
BY DEF Invariant, Inv_ml_tl_ty, Inv_ml_tl_ok, Inv_il_tl_ty, Inv_il_tl_ok, Inv_il_tl_ml_tl_excl, _il_green, GRD_il_green, ACT_il_green, il_green

THEOREM PO_Init_ml_tl_ok == Init => Inv_ml_tl_ok
PROOF
BY DEF Init, Inv_ml_tl_ok

THEOREM PO_Next_ml_tl_ok == Invariant /\ Next /\ Inv_ml_tl_ty' => Inv_ml_tl_ok'
PROOF
BY THEOREM PO_Next_ML2BR_ml_tl_ok, THEOREM PO_Next_BR2ML_ml_tl_ok, THEOREM PO_Next_BR2IL_ml_tl_ok, THEOREM PO_Next_IL2BR_ml_tl_ok, THEOREM PO_Next_ml_green_ml_tl_ok, THEOREM PO_Next_il_green_ml_tl_ok DEF Next

THEOREM PO_Next_ML2BR_il_tl_ty == Invariant /\ Inv_ml_tl_ty' /\ Inv_ml_tl_ok' /\ _ML2BR => Inv_il_tl_ty'
PROOF
BY DEF Invariant, Inv_ml_tl_ty, Inv_ml_tl_ok, Inv_il_tl_ty, Inv_il_tl_ok, Inv_il_tl_ml_tl_excl, _ML2BR, GRD_ML2BR, ACT_ML2BR, ML2BR

THEOREM PO_Next_BR2ML_il_tl_ty == Invariant /\ Inv_ml_tl_ty' /\ Inv_ml_tl_ok' /\ _BR2ML => Inv_il_tl_ty'
PROOF
BY DEF Invariant, Inv_ml_tl_ty, Inv_ml_tl_ok, Inv_il_tl_ty, Inv_il_tl_ok, Inv_il_tl_ml_tl_excl, _BR2ML, GRD_BR2ML, ACT_BR2ML, BR2ML

THEOREM PO_Next_BR2IL_il_tl_ty == Invariant /\ Inv_ml_tl_ty' /\ Inv_ml_tl_ok' /\ _BR2IL => Inv_il_tl_ty'
PROOF
BY DEF Invariant, Inv_ml_tl_ty, Inv_ml_tl_ok, Inv_il_tl_ty, Inv_il_tl_ok, Inv_il_tl_ml_tl_excl, _BR2IL, GRD_BR2IL, ACT_BR2IL, BR2IL

THEOREM PO_Next_IL2BR_il_tl_ty == Invariant /\ Inv_ml_tl_ty' /\ Inv_ml_tl_ok' /\ _IL2BR => Inv_il_tl_ty'
PROOF
BY DEF Invariant, Inv_ml_tl_ty, Inv_ml_tl_ok, Inv_il_tl_ty, Inv_il_tl_ok, Inv_il_tl_ml_tl_excl, _IL2BR, GRD_IL2BR, ACT_IL2BR, IL2BR

THEOREM PO_Next_ml_green_il_tl_ty == Invariant /\ Inv_ml_tl_ty' /\ Inv_ml_tl_ok' /\ _ml_green => Inv_il_tl_ty'
PROOF
BY DEF Invariant, Inv_ml_tl_ty, Inv_ml_tl_ok, Inv_il_tl_ty, Inv_il_tl_ok, Inv_il_tl_ml_tl_excl, _ml_green, GRD_ml_green, ACT_ml_green, ml_green

THEOREM PO_Next_il_green_il_tl_ty == Invariant /\ Inv_ml_tl_ty' /\ Inv_ml_tl_ok' /\ _il_green => Inv_il_tl_ty'
PROOF
BY DEF Invariant, Inv_ml_tl_ty, Inv_ml_tl_ok, Inv_il_tl_ty, Inv_il_tl_ok, Inv_il_tl_ml_tl_excl, _il_green, GRD_il_green, ACT_il_green, il_green

THEOREM PO_Init_il_tl_ty == Init => Inv_il_tl_ty
PROOF
BY DEF Init, Inv_il_tl_ty

THEOREM PO_Next_il_tl_ty == Invariant /\ Next /\ Inv_ml_tl_ty' /\ Inv_ml_tl_ok' => Inv_il_tl_ty'
PROOF
BY THEOREM PO_Next_ML2BR_il_tl_ty, THEOREM PO_Next_BR2ML_il_tl_ty, THEOREM PO_Next_BR2IL_il_tl_ty, THEOREM PO_Next_IL2BR_il_tl_ty, THEOREM PO_Next_ml_green_il_tl_ty, THEOREM PO_Next_il_green_il_tl_ty DEF Next

THEOREM PO_Next_ML2BR_il_tl_ok == Invariant /\ Inv_ml_tl_ty' /\ Inv_ml_tl_ok' /\ Inv_il_tl_ty' /\ _ML2BR => Inv_il_tl_ok'
PROOF
BY DEF Invariant, Inv_ml_tl_ty, Inv_ml_tl_ok, Inv_il_tl_ty, Inv_il_tl_ok, Inv_il_tl_ml_tl_excl, _ML2BR, GRD_ML2BR, ACT_ML2BR, ML2BR

THEOREM PO_Next_BR2ML_il_tl_ok == Invariant /\ Inv_ml_tl_ty' /\ Inv_ml_tl_ok' /\ Inv_il_tl_ty' /\ _BR2ML => Inv_il_tl_ok'
PROOF
BY DEF Invariant, Inv_ml_tl_ty, Inv_ml_tl_ok, Inv_il_tl_ty, Inv_il_tl_ok, Inv_il_tl_ml_tl_excl, _BR2ML, GRD_BR2ML, ACT_BR2ML, BR2ML

THEOREM PO_Next_BR2IL_il_tl_ok == Invariant /\ Inv_ml_tl_ty' /\ Inv_ml_tl_ok' /\ Inv_il_tl_ty' /\ _BR2IL => Inv_il_tl_ok'
PROOF
BY DEF Invariant, Inv_ml_tl_ty, Inv_ml_tl_ok, Inv_il_tl_ty, Inv_il_tl_ok, Inv_il_tl_ml_tl_excl, _BR2IL, GRD_BR2IL, ACT_BR2IL, BR2IL

THEOREM PO_Next_IL2BR_il_tl_ok == Invariant /\ Inv_ml_tl_ty' /\ Inv_ml_tl_ok' /\ Inv_il_tl_ty' /\ _IL2BR => Inv_il_tl_ok'
PROOF
BY DEF Invariant, Inv_ml_tl_ty, Inv_ml_tl_ok, Inv_il_tl_ty, Inv_il_tl_ok, Inv_il_tl_ml_tl_excl, _IL2BR, GRD_IL2BR, ACT_IL2BR, IL2BR

THEOREM PO_Next_ml_green_il_tl_ok == Invariant /\ Inv_ml_tl_ty' /\ Inv_ml_tl_ok' /\ Inv_il_tl_ty' /\ _ml_green => Inv_il_tl_ok'
PROOF
BY DEF Invariant, Inv_ml_tl_ty, Inv_ml_tl_ok, Inv_il_tl_ty, Inv_il_tl_ok, Inv_il_tl_ml_tl_excl, _ml_green, GRD_ml_green, ACT_ml_green, ml_green

THEOREM PO_Next_il_green_il_tl_ok == Invariant /\ Inv_ml_tl_ty' /\ Inv_ml_tl_ok' /\ Inv_il_tl_ty' /\ _il_green => Inv_il_tl_ok'
PROOF
BY DEF Invariant, Inv_ml_tl_ty, Inv_ml_tl_ok, Inv_il_tl_ty, Inv_il_tl_ok, Inv_il_tl_ml_tl_excl, _il_green, GRD_il_green, ACT_il_green, il_green

THEOREM PO_Init_il_tl_ok == Init => Inv_il_tl_ok
PROOF
BY DEF Init, Inv_il_tl_ok

THEOREM PO_Next_il_tl_ok == Invariant /\ Next /\ Inv_ml_tl_ty' /\ Inv_ml_tl_ok' /\ Inv_il_tl_ty' => Inv_il_tl_ok'
PROOF
BY THEOREM PO_Next_ML2BR_il_tl_ok, THEOREM PO_Next_BR2ML_il_tl_ok, THEOREM PO_Next_BR2IL_il_tl_ok, THEOREM PO_Next_IL2BR_il_tl_ok, THEOREM PO_Next_ml_green_il_tl_ok, THEOREM PO_Next_il_green_il_tl_ok DEF Next

THEOREM PO_Next_ML2BR_il_tl_ml_tl_excl == Invariant /\ Inv_ml_tl_ty' /\ Inv_ml_tl_ok' /\ Inv_il_tl_ty' /\ Inv_il_tl_ok' /\ _ML2BR => Inv_il_tl_ml_tl_excl'
PROOF
BY DEF Invariant, Inv_ml_tl_ty, Inv_ml_tl_ok, Inv_il_tl_ty, Inv_il_tl_ok, Inv_il_tl_ml_tl_excl, _ML2BR, GRD_ML2BR, ACT_ML2BR, ML2BR

THEOREM PO_Next_BR2ML_il_tl_ml_tl_excl == Invariant /\ Inv_ml_tl_ty' /\ Inv_ml_tl_ok' /\ Inv_il_tl_ty' /\ Inv_il_tl_ok' /\ _BR2ML => Inv_il_tl_ml_tl_excl'
PROOF
BY DEF Invariant, Inv_ml_tl_ty, Inv_ml_tl_ok, Inv_il_tl_ty, Inv_il_tl_ok, Inv_il_tl_ml_tl_excl, _BR2ML, GRD_BR2ML, ACT_BR2ML, BR2ML

THEOREM PO_Next_BR2IL_il_tl_ml_tl_excl == Invariant /\ Inv_ml_tl_ty' /\ Inv_ml_tl_ok' /\ Inv_il_tl_ty' /\ Inv_il_tl_ok' /\ _BR2IL => Inv_il_tl_ml_tl_excl'
PROOF
BY DEF Invariant, Inv_ml_tl_ty, Inv_ml_tl_ok, Inv_il_tl_ty, Inv_il_tl_ok, Inv_il_tl_ml_tl_excl, _BR2IL, GRD_BR2IL, ACT_BR2IL, BR2IL

THEOREM PO_Next_IL2BR_il_tl_ml_tl_excl == Invariant /\ Inv_ml_tl_ty' /\ Inv_ml_tl_ok' /\ Inv_il_tl_ty' /\ Inv_il_tl_ok' /\ _IL2BR => Inv_il_tl_ml_tl_excl'
PROOF
BY DEF Invariant, Inv_ml_tl_ty, Inv_ml_tl_ok, Inv_il_tl_ty, Inv_il_tl_ok, Inv_il_tl_ml_tl_excl, _IL2BR, GRD_IL2BR, ACT_IL2BR, IL2BR

THEOREM PO_Next_ml_green_il_tl_ml_tl_excl == Invariant /\ Inv_ml_tl_ty' /\ Inv_ml_tl_ok' /\ Inv_il_tl_ty' /\ Inv_il_tl_ok' /\ _ml_green => Inv_il_tl_ml_tl_excl'
PROOF
BY DEF Invariant, Inv_ml_tl_ty, Inv_ml_tl_ok, Inv_il_tl_ty, Inv_il_tl_ok, Inv_il_tl_ml_tl_excl, _ml_green, GRD_ml_green, ACT_ml_green, ml_green

THEOREM PO_Next_il_green_il_tl_ml_tl_excl == Invariant /\ Inv_ml_tl_ty' /\ Inv_ml_tl_ok' /\ Inv_il_tl_ty' /\ Inv_il_tl_ok' /\ _il_green => Inv_il_tl_ml_tl_excl'
PROOF
BY DEF Invariant, Inv_ml_tl_ty, Inv_ml_tl_ok, Inv_il_tl_ty, Inv_il_tl_ok, Inv_il_tl_ml_tl_excl, _il_green, GRD_il_green, ACT_il_green, il_green

THEOREM PO_Init_il_tl_ml_tl_excl == Init => Inv_il_tl_ml_tl_excl
PROOF
BY DEF Init, Inv_il_tl_ml_tl_excl

THEOREM PO_Next_il_tl_ml_tl_excl == Invariant /\ Next /\ Inv_ml_tl_ty' /\ Inv_ml_tl_ok' /\ Inv_il_tl_ty' /\ Inv_il_tl_ok' => Inv_il_tl_ml_tl_excl'
PROOF
BY THEOREM PO_Next_ML2BR_il_tl_ml_tl_excl, THEOREM PO_Next_BR2ML_il_tl_ml_tl_excl, THEOREM PO_Next_BR2IL_il_tl_ml_tl_excl, THEOREM PO_Next_IL2BR_il_tl_ml_tl_excl, THEOREM PO_Next_ml_green_il_tl_ml_tl_excl, THEOREM PO_Next_il_green_il_tl_ml_tl_excl DEF Next


THEOREM InvariantIsPreserved == Invariant /\ Next => Invariant'
PROOF
BY THEOREM PO_Next_ml_tl_ty, THEOREM PO_Next_ml_tl_ok, THEOREM PO_Next_il_tl_ty, THEOREM PO_Next_il_tl_ok, THEOREM PO_Next_il_tl_ml_tl_excl DEF Invariant

THEOREM NoDeadlock == Invariant => 
	\/ GRD_ML2BR
	\/ GRD_BR2ML
	\/ GRD_BR2IL
	\/ GRD_IL2BR
	\/ GRD_ml_green
	\/ GRD_il_green
PROOF
	BY DEF GRD_ML2BR,GRD_BR2ML,GRD_BR2IL,GRD_IL2BR,GRD_ml_green,GRD_il_green, Invariant,Inv_ml_tl_ty,Inv_ml_tl_ok,Inv_il_tl_ty,Inv_il_tl_ok,Inv_il_tl_ml_tl_excl
========================================
