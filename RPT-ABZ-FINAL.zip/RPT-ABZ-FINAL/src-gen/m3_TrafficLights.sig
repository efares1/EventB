process m3_TrafficLights = (? integer cmd; )
(|
	  INITIALISATION ^= when cmd = E_INITIALISATION 
	| ML2BR ^= when cmd = E_ML2BR when  ml_tl =  green
	| BR2ML ^= when cmd = E_BR2ML 
	| BR2IL ^= when cmd = E_BR2IL 
	| IL2BR ^= when cmd = E_IL2BR when   islecars − 1≥0 when  il_tl =  green
	| ml_green ^= when cmd = E_ml_green when  ml_tl =  red when   exiting=0 when   ¬cars=capacity
	| il_green ^= when cmd = E_il_green when  il_tl =  red when   entering=0
	| cmd ^= ^INITIALISATION ^+ ^ML2BR ^+ ^BR2ML ^+ ^BR2IL ^+ ^IL2BR ^+ ^ml_green ^+ ^il_green
|) where event INITIALISATION; event ML2BR; event BR2ML; event BR2IL; event IL2BR; event ml_green; event il_green,
	constant integer E_INITIALISATION = 0;
	constant integer E_ML2BR = 1;
	constant integer E_BR2ML = 2;
	constant integer E_BR2IL = 3;
	constant integer E_IL2BR = 4;
	constant integer E_ml_green = 5;
	constant integer E_il_green = 6
   end;
