process m2_BridgeToIsle = (? integer cmd; )
(|
	  INITIALISATION ^= when cmd = E_INITIALISATION 
	| ML2BR ^= when cmd = E_ML2BR when  exiting=0
	| BR2ML ^= when cmd = E_BR2ML when  entering=0∨exiting − 1=0 when  exiting − 1≥0
	| BR2IL ^= when cmd = E_BR2IL when  entering − 1=0∨exiting=0 when  entering − 1≥0
	| IL2BR ^= when cmd = E_IL2BR when  entering=0 when  islecars − 1≥0
	| cmd ^= ^INITIALISATION ^+ ^ML2BR ^+ ^BR2ML ^+ ^BR2IL ^+ ^IL2BR
|) where event INITIALISATION; event ML2BR; event BR2ML; event BR2IL; event IL2BR,
	constant integer E_INITIALISATION = 0;
	constant integer E_ML2BR = 1;
	constant integer E_BR2ML = 2;
	constant integer E_BR2IL = 3;
	constant integer E_IL2BR = 4
   end;
