let m1_IsleCapacity = {
	name = "m1_IsleCapacity";
	refines = [m0_IsleAccess];
	sees = [cCapacity];
	variables = ["cars"];
	invariants = [{name = "cars_ty"; predicate =  cars ∈ ℤ}
	; {name = "capacity"; predicate =   cars ∈ 0‥capacity}
	];
	events = [{
		name = "INITIALISATION";
		refinements = [];
		parameters = [];
		guards = [];
		witness = [];
		action = [{name = "cars"; action = {left = ["cars"]; right = [ 0]}
		}
		]
	}
	; {
		name = "ML2BR";
		refinements = [];
		parameters = [];
		guards = [{name = "capacity"; predicate =  ¬cars=capacity}
		];
		witness = [];
		action = [{name = "cars"; action = {left = ["cars"]; right = [ cars+1]}
		}
		]
	}
	; {
		name = "BR2ML";
		refinements = [];
		parameters = [];
		guards = [{name = "capacity"; predicate =  cars − 1∈0 ‥ capacity}
		];
		witness = [];
		action = [{name = "cars"; action = {left = ["cars"]; right = [ cars−1]}
		}
		]
	}
	]
}
