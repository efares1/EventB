(*
machine m4_Sensors refines m3_TrafficLights
sees cColor cCapacity
variables
	entering
	islecars
	exiting
	cars
	ml_tl
	il_tl
	ml_out_10
	il_out_10
	ml_in_10
	il_in_10
invariants
	@ml_out_10_ty ml_out_10 ∈ BOOL
	@ml_out_10_ok ml_out_10=TRUE⇒ml_tl=green
	@il_out_10_ty il_out_10 ∈ BOOL
	@il_out_10_ok il_out_10=TRUE⇒il_tl=green
	@ml_in_10_ty ml_in_10 ∈ BOOL
	@il_in_10_ty il_in_10 ∈ BOOL
events
	event INITIALISATION extends INITIALISATION
	then
		@ml_out_10 ml_out_10 ≔ FALSE
		@il_out_10 il_out_10 ≔ FALSE
		@ml_in_10 ml_in_10 ≔ FALSE
		@il_in_10 il_in_10 ≔ FALSE
	end
	event ML2BR refines ML2BR
	when
		@ml_out_10_ok ml_out_10 = TRUE
		@IL2BR_il_tl_ok il_out_10=TRUE⇒il_tl=green
	then
		@ml_out_10_ko ml_out_10 ≔ FALSE
		@ml_tl_ko ml_tl ≔   red
		@entering entering ≔   entering+1
	end
	event BR2ML refines BR2ML
	when
		@ml_in_10_ok ml_in_10 = TRUE
		@ML2BR_ml_tl_ok ml_out_10=TRUE⇒{TRUE ↦ red,FALSE ↦ ml_tl}(bool(ml_tl=green∧¬(exiting − 1=0∧¬cars − 1=capacity)))=green
		@IL2BR_il_tl_ok il_out_10=TRUE⇒{TRUE ↦ red,FALSE ↦ il_tl}(bool(il_tl=green∧¬entering=0))=green
	then
		@ml_in_10_ko ml_in_10 ≔ FALSE
		@ml_tl_ko ml_tl ≔  {TRUE ↦ red,FALSE ↦ ml_tl}(bool(ml_tl=green∧¬(exiting − 1=0∧¬cars − 1=capacity)))
		@il_tl_ko il_tl ≔  {TRUE ↦ red,FALSE ↦ il_tl}(bool(il_tl=green∧¬entering=0))
	end
	event BR2IL refines BR2IL
	when
		@il_in_10_ok il_in_10 = TRUE
		@ML2BR_ml_tl_ok ml_out_10=TRUE⇒{TRUE ↦ red,FALSE ↦ ml_tl}(bool(ml_tl=green∧¬(exiting=0∧¬cars=capacity)))=green
		@IL2BR_il_tl_ok il_out_10=TRUE⇒{TRUE ↦ red,FALSE ↦ il_tl}(bool(il_tl=green∧¬entering − 1=0))=green
	then
		@il_in_10_ko il_in_10 ≔ FALSE
		@ml_tl_ko ml_tl ≔  {TRUE ↦ red,FALSE ↦ ml_tl}(bool(ml_tl=green∧¬(exiting=0∧¬cars=capacity)))
		@il_tl_ko il_tl ≔  {TRUE ↦ red,FALSE ↦ il_tl}(bool(il_tl=green∧¬entering − 1=0))
	end
	event IL2BR refines IL2BR
	when
		@stay_ctr   islecars − 1≥0
		@il_out_10_ok il_out_10 = TRUE
		@ML2BR_ml_tl_ok ml_out_10=TRUE⇒ml_tl=green
	then
		@il_out_10_ko il_out_10 ≔ FALSE
		@il_tl_ko il_tl ≔   red
		@exiting exiting ≔   exiting+1
		@islecars islecars ≔   islecars−1
	end
	event ml_green extends ml_green
	then
		@il_out_10_ko il_out_10 ≔ FALSE
	end
	event il_green extends il_green
	then
		@ml_out_10_ko ml_out_10 ≔ FALSE
	end
	event ML2BR_sensor
	when
		@ml_out_10_ko ml_out_10 = FALSE
		@ml_tl_ok  ml_tl =  green
	then
		@ml_out_10 ml_out_10 ≔ TRUE
	end
	event IL2BR_sensor
	when
		@il_out_10_ko il_out_10 = FALSE
		@il_tl_ok  il_tl =  green
	then
		@il_out_10 il_out_10 ≔ TRUE
	end
	event BR2ML_sensor
	when
		@ml_in_10_ko ml_in_10 = FALSE
	then
		@ml_in_10 ml_in_10 ≔ TRUE
	end
	event BR2IL_sensor
	when
		@il_in_10_ko il_in_10 = FALSE
	then
		@il_in_10 il_in_10 ≔ TRUE
	end
end
*)
------- MODULE m4_Sensors -------
EXTENDS Integers, TLAPS, cColor, cCapacity
VARIABLES
	event, entering, islecars, exiting, cars, ml_tl, il_tl, ml_out_10, il_out_10, ml_in_10, il_in_10
vars == <<event, entering, islecars, exiting, cars, ml_tl, il_tl, ml_out_10, il_out_10, ml_in_10, il_in_10>>
Inv_ml_out_10_ty == (ml_out_10 \in BOOLEAN)
Inv_ml_out_10_ok == ((ml_out_10 = TRUE) => (ml_tl = green))
Inv_il_out_10_ty == (il_out_10 \in BOOLEAN)
Inv_il_out_10_ok == ((il_out_10 = TRUE) => (il_tl = green))
Inv_ml_in_10_ty == (ml_in_10 \in BOOLEAN)
Inv_il_in_10_ty == (il_in_10 \in BOOLEAN)

Invariant ==
	/\ Inv_ml_out_10_ty
	/\ Inv_ml_out_10_ok
	/\ Inv_il_out_10_ty
	/\ Inv_il_out_10_ok
	/\ Inv_ml_in_10_ty
	/\ Inv_il_in_10_ty

Init == 
	/\ event = <<"INITIALISATION">>
	/\ <<ml_out_10>> = <<FALSE>>
	/\ <<il_out_10>> = <<FALSE>>
	/\ <<ml_in_10>> = <<FALSE>>
	/\ <<il_in_10>> = <<FALSE>>
ML2BR  == event = <<"ML2BR">>
GRD_ML2BR ==
	/\ (ml_out_10 = TRUE)
	/\ ((il_out_10 = TRUE) => (il_tl = green))
ACT_ML2BR ==
	/\ <<ml_out_10'>> = <<FALSE>>
	/\ <<ml_tl'>> = <<red>>
	/\ <<entering'>> = <<(entering+1)>>
	/\ UNCHANGED(<<islecars,exiting,cars,il_tl,il_out_10,ml_in_10,il_in_10>>)
_ML2BR  ==
	/\ ML2BR'
	/\ GRD_ML2BR
	/\ ACT_ML2BR
BR2ML  == event = <<"BR2ML">>
GRD_BR2ML ==
	/\ (ml_in_10 = TRUE)
	/\ ((ml_out_10 = TRUE) => (APPLY({ <<TRUE, red>>, <<FALSE, ml_tl>>})[(ml_tl = green) /\  (\neg ((exiting - 1) = 0) /\  (\neg ((cars - 1) = capacity)) ) ] = green))
	/\ ((il_out_10 = TRUE) => (APPLY({ <<TRUE, red>>, <<FALSE, il_tl>>})[(il_tl = green) /\  (\neg (entering = 0)) ] = green))
ACT_BR2ML ==
	/\ <<ml_in_10'>> = <<FALSE>>
	/\ <<ml_tl'>> = <<APPLY({ <<TRUE, red>>, <<FALSE, ml_tl>>})[(ml_tl = green) /\  (\neg ((exiting - 1) = 0) /\  (\neg ((cars - 1) = capacity)) ) ]>>
	/\ <<il_tl'>> = <<APPLY({ <<TRUE, red>>, <<FALSE, il_tl>>})[(il_tl = green) /\  (\neg (entering = 0)) ]>>
	/\ UNCHANGED(<<entering,islecars,exiting,cars,ml_out_10,il_out_10,il_in_10>>)
_BR2ML  ==
	/\ BR2ML'
	/\ GRD_BR2ML
	/\ ACT_BR2ML
BR2IL  == event = <<"BR2IL">>
GRD_BR2IL ==
	/\ (il_in_10 = TRUE)
	/\ ((ml_out_10 = TRUE) => (APPLY({ <<TRUE, red>>, <<FALSE, ml_tl>>})[(ml_tl = green) /\  (\neg (exiting = 0) /\  (\neg (cars = capacity)) ) ] = green))
	/\ ((il_out_10 = TRUE) => (APPLY({ <<TRUE, red>>, <<FALSE, il_tl>>})[(il_tl = green) /\  (\neg ((entering - 1) = 0)) ] = green))
ACT_BR2IL ==
	/\ <<il_in_10'>> = <<FALSE>>
	/\ <<ml_tl'>> = <<APPLY({ <<TRUE, red>>, <<FALSE, ml_tl>>})[(ml_tl = green) /\  (\neg (exiting = 0) /\  (\neg (cars = capacity)) ) ]>>
	/\ <<il_tl'>> = <<APPLY({ <<TRUE, red>>, <<FALSE, il_tl>>})[(il_tl = green) /\  (\neg ((entering - 1) = 0)) ]>>
	/\ UNCHANGED(<<entering,islecars,exiting,cars,ml_out_10,il_out_10,ml_in_10>>)
_BR2IL  ==
	/\ BR2IL'
	/\ GRD_BR2IL
	/\ ACT_BR2IL
IL2BR  == event = <<"IL2BR">>
GRD_IL2BR ==
	/\ ((islecars - 1) >= 0)
	/\ (il_out_10 = TRUE)
	/\ ((ml_out_10 = TRUE) => (ml_tl = green))
ACT_IL2BR ==
	/\ <<il_out_10'>> = <<FALSE>>
	/\ <<il_tl'>> = <<red>>
	/\ <<exiting'>> = <<(exiting+1)>>
	/\ <<islecars'>> = <<(islecars - 1)>>
	/\ UNCHANGED(<<entering,cars,ml_tl,ml_out_10,ml_in_10,il_in_10>>)
_IL2BR  ==
	/\ IL2BR'
	/\ GRD_IL2BR
	/\ ACT_IL2BR
ml_green  == event = <<"ml_green">>
GRD_ml_green ==
ACT_ml_green ==
	/\ <<il_out_10'>> = <<FALSE>>
	/\ UNCHANGED(<<entering,islecars,exiting,cars,ml_tl,il_tl,ml_out_10,ml_in_10,il_in_10>>)
_ml_green  ==
	/\ ml_green'
	/\ GRD_ml_green
	/\ ACT_ml_green
il_green  == event = <<"il_green">>
GRD_il_green ==
ACT_il_green ==
	/\ <<ml_out_10'>> = <<FALSE>>
	/\ UNCHANGED(<<entering,islecars,exiting,cars,ml_tl,il_tl,il_out_10,ml_in_10,il_in_10>>)
_il_green  ==
	/\ il_green'
	/\ GRD_il_green
	/\ ACT_il_green
ML2BR_sensor  == event = <<"ML2BR_sensor">>
GRD_ML2BR_sensor ==
	/\ (ml_out_10 = FALSE)
	/\ (ml_tl = green)
ACT_ML2BR_sensor ==
	/\ <<ml_out_10'>> = <<TRUE>>
	/\ UNCHANGED(<<entering,islecars,exiting,cars,ml_tl,il_tl,il_out_10,ml_in_10,il_in_10>>)
_ML2BR_sensor  ==
	/\ ML2BR_sensor'
	/\ GRD_ML2BR_sensor
	/\ ACT_ML2BR_sensor
IL2BR_sensor  == event = <<"IL2BR_sensor">>
GRD_IL2BR_sensor ==
	/\ (il_out_10 = FALSE)
	/\ (il_tl = green)
ACT_IL2BR_sensor ==
	/\ <<il_out_10'>> = <<TRUE>>
	/\ UNCHANGED(<<entering,islecars,exiting,cars,ml_tl,il_tl,ml_out_10,ml_in_10,il_in_10>>)
_IL2BR_sensor  ==
	/\ IL2BR_sensor'
	/\ GRD_IL2BR_sensor
	/\ ACT_IL2BR_sensor
BR2ML_sensor  == event = <<"BR2ML_sensor">>
GRD_BR2ML_sensor ==
	/\ (ml_in_10 = FALSE)
ACT_BR2ML_sensor ==
	/\ <<ml_in_10'>> = <<TRUE>>
	/\ UNCHANGED(<<entering,islecars,exiting,cars,ml_tl,il_tl,ml_out_10,il_out_10,il_in_10>>)
_BR2ML_sensor  ==
	/\ BR2ML_sensor'
	/\ GRD_BR2ML_sensor
	/\ ACT_BR2ML_sensor
BR2IL_sensor  == event = <<"BR2IL_sensor">>
GRD_BR2IL_sensor ==
	/\ (il_in_10 = FALSE)
ACT_BR2IL_sensor ==
	/\ <<il_in_10'>> = <<TRUE>>
	/\ UNCHANGED(<<entering,islecars,exiting,cars,ml_tl,il_tl,ml_out_10,il_out_10,ml_in_10>>)
_BR2IL_sensor  ==
	/\ BR2IL_sensor'
	/\ GRD_BR2IL_sensor
	/\ ACT_BR2IL_sensor

Next ==
	\/ _ML2BR
	\/ _BR2ML
	\/ _BR2IL
	\/ _IL2BR
	\/ _ml_green
	\/ _il_green
	\/ _ML2BR_sensor
	\/ _IL2BR_sensor
	\/ _BR2ML_sensor
	\/ _BR2IL_sensor

Spec == Init /\ [][Next]_vars
THEOREM PO_Next_ML2BR_ml_out_10_ty == Invariant /\ _ML2BR => Inv_ml_out_10_ty'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _ML2BR, GRD_ML2BR, ACT_ML2BR, ML2BR

THEOREM PO_Next_BR2ML_ml_out_10_ty == Invariant /\ _BR2ML => Inv_ml_out_10_ty'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _BR2ML, GRD_BR2ML, ACT_BR2ML, BR2ML

THEOREM PO_Next_BR2IL_ml_out_10_ty == Invariant /\ _BR2IL => Inv_ml_out_10_ty'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _BR2IL, GRD_BR2IL, ACT_BR2IL, BR2IL

THEOREM PO_Next_IL2BR_ml_out_10_ty == Invariant /\ _IL2BR => Inv_ml_out_10_ty'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _IL2BR, GRD_IL2BR, ACT_IL2BR, IL2BR

THEOREM PO_Next_ml_green_ml_out_10_ty == Invariant /\ _ml_green => Inv_ml_out_10_ty'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _ml_green, GRD_ml_green, ACT_ml_green, ml_green

THEOREM PO_Next_il_green_ml_out_10_ty == Invariant /\ _il_green => Inv_ml_out_10_ty'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _il_green, GRD_il_green, ACT_il_green, il_green

THEOREM PO_Next_ML2BR_sensor_ml_out_10_ty == Invariant /\ _ML2BR_sensor => Inv_ml_out_10_ty'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _ML2BR_sensor, GRD_ML2BR_sensor, ACT_ML2BR_sensor, ML2BR_sensor

THEOREM PO_Next_IL2BR_sensor_ml_out_10_ty == Invariant /\ _IL2BR_sensor => Inv_ml_out_10_ty'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _IL2BR_sensor, GRD_IL2BR_sensor, ACT_IL2BR_sensor, IL2BR_sensor

THEOREM PO_Next_BR2ML_sensor_ml_out_10_ty == Invariant /\ _BR2ML_sensor => Inv_ml_out_10_ty'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _BR2ML_sensor, GRD_BR2ML_sensor, ACT_BR2ML_sensor, BR2ML_sensor

THEOREM PO_Next_BR2IL_sensor_ml_out_10_ty == Invariant /\ _BR2IL_sensor => Inv_ml_out_10_ty'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _BR2IL_sensor, GRD_BR2IL_sensor, ACT_BR2IL_sensor, BR2IL_sensor

THEOREM PO_Init_ml_out_10_ty == Init => Inv_ml_out_10_ty
PROOF
BY DEF Init, Inv_ml_out_10_ty

THEOREM PO_Next_ml_out_10_ty == Invariant /\ Next => Inv_ml_out_10_ty'
PROOF
BY THEOREM PO_Next_ML2BR_ml_out_10_ty, THEOREM PO_Next_BR2ML_ml_out_10_ty, THEOREM PO_Next_BR2IL_ml_out_10_ty, THEOREM PO_Next_IL2BR_ml_out_10_ty, THEOREM PO_Next_ml_green_ml_out_10_ty, THEOREM PO_Next_il_green_ml_out_10_ty, THEOREM PO_Next_ML2BR_sensor_ml_out_10_ty, THEOREM PO_Next_IL2BR_sensor_ml_out_10_ty, THEOREM PO_Next_BR2ML_sensor_ml_out_10_ty, THEOREM PO_Next_BR2IL_sensor_ml_out_10_ty DEF Next

THEOREM PO_Next_ML2BR_ml_out_10_ok == Invariant /\ Inv_ml_out_10_ty' /\ _ML2BR => Inv_ml_out_10_ok'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _ML2BR, GRD_ML2BR, ACT_ML2BR, ML2BR

THEOREM PO_Next_BR2ML_ml_out_10_ok == Invariant /\ Inv_ml_out_10_ty' /\ _BR2ML => Inv_ml_out_10_ok'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _BR2ML, GRD_BR2ML, ACT_BR2ML, BR2ML

THEOREM PO_Next_BR2IL_ml_out_10_ok == Invariant /\ Inv_ml_out_10_ty' /\ _BR2IL => Inv_ml_out_10_ok'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _BR2IL, GRD_BR2IL, ACT_BR2IL, BR2IL

THEOREM PO_Next_IL2BR_ml_out_10_ok == Invariant /\ Inv_ml_out_10_ty' /\ _IL2BR => Inv_ml_out_10_ok'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _IL2BR, GRD_IL2BR, ACT_IL2BR, IL2BR

THEOREM PO_Next_ml_green_ml_out_10_ok == Invariant /\ Inv_ml_out_10_ty' /\ _ml_green => Inv_ml_out_10_ok'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _ml_green, GRD_ml_green, ACT_ml_green, ml_green

THEOREM PO_Next_il_green_ml_out_10_ok == Invariant /\ Inv_ml_out_10_ty' /\ _il_green => Inv_ml_out_10_ok'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _il_green, GRD_il_green, ACT_il_green, il_green

THEOREM PO_Next_ML2BR_sensor_ml_out_10_ok == Invariant /\ Inv_ml_out_10_ty' /\ _ML2BR_sensor => Inv_ml_out_10_ok'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _ML2BR_sensor, GRD_ML2BR_sensor, ACT_ML2BR_sensor, ML2BR_sensor

THEOREM PO_Next_IL2BR_sensor_ml_out_10_ok == Invariant /\ Inv_ml_out_10_ty' /\ _IL2BR_sensor => Inv_ml_out_10_ok'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _IL2BR_sensor, GRD_IL2BR_sensor, ACT_IL2BR_sensor, IL2BR_sensor

THEOREM PO_Next_BR2ML_sensor_ml_out_10_ok == Invariant /\ Inv_ml_out_10_ty' /\ _BR2ML_sensor => Inv_ml_out_10_ok'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _BR2ML_sensor, GRD_BR2ML_sensor, ACT_BR2ML_sensor, BR2ML_sensor

THEOREM PO_Next_BR2IL_sensor_ml_out_10_ok == Invariant /\ Inv_ml_out_10_ty' /\ _BR2IL_sensor => Inv_ml_out_10_ok'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _BR2IL_sensor, GRD_BR2IL_sensor, ACT_BR2IL_sensor, BR2IL_sensor

THEOREM PO_Init_ml_out_10_ok == Init => Inv_ml_out_10_ok
PROOF
BY DEF Init, Inv_ml_out_10_ok

THEOREM PO_Next_ml_out_10_ok == Invariant /\ Next /\ Inv_ml_out_10_ty' => Inv_ml_out_10_ok'
PROOF
BY THEOREM PO_Next_ML2BR_ml_out_10_ok, THEOREM PO_Next_BR2ML_ml_out_10_ok, THEOREM PO_Next_BR2IL_ml_out_10_ok, THEOREM PO_Next_IL2BR_ml_out_10_ok, THEOREM PO_Next_ml_green_ml_out_10_ok, THEOREM PO_Next_il_green_ml_out_10_ok, THEOREM PO_Next_ML2BR_sensor_ml_out_10_ok, THEOREM PO_Next_IL2BR_sensor_ml_out_10_ok, THEOREM PO_Next_BR2ML_sensor_ml_out_10_ok, THEOREM PO_Next_BR2IL_sensor_ml_out_10_ok DEF Next

THEOREM PO_Next_ML2BR_il_out_10_ty == Invariant /\ Inv_ml_out_10_ty' /\ Inv_ml_out_10_ok' /\ _ML2BR => Inv_il_out_10_ty'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _ML2BR, GRD_ML2BR, ACT_ML2BR, ML2BR

THEOREM PO_Next_BR2ML_il_out_10_ty == Invariant /\ Inv_ml_out_10_ty' /\ Inv_ml_out_10_ok' /\ _BR2ML => Inv_il_out_10_ty'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _BR2ML, GRD_BR2ML, ACT_BR2ML, BR2ML

THEOREM PO_Next_BR2IL_il_out_10_ty == Invariant /\ Inv_ml_out_10_ty' /\ Inv_ml_out_10_ok' /\ _BR2IL => Inv_il_out_10_ty'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _BR2IL, GRD_BR2IL, ACT_BR2IL, BR2IL

THEOREM PO_Next_IL2BR_il_out_10_ty == Invariant /\ Inv_ml_out_10_ty' /\ Inv_ml_out_10_ok' /\ _IL2BR => Inv_il_out_10_ty'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _IL2BR, GRD_IL2BR, ACT_IL2BR, IL2BR

THEOREM PO_Next_ml_green_il_out_10_ty == Invariant /\ Inv_ml_out_10_ty' /\ Inv_ml_out_10_ok' /\ _ml_green => Inv_il_out_10_ty'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _ml_green, GRD_ml_green, ACT_ml_green, ml_green

THEOREM PO_Next_il_green_il_out_10_ty == Invariant /\ Inv_ml_out_10_ty' /\ Inv_ml_out_10_ok' /\ _il_green => Inv_il_out_10_ty'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _il_green, GRD_il_green, ACT_il_green, il_green

THEOREM PO_Next_ML2BR_sensor_il_out_10_ty == Invariant /\ Inv_ml_out_10_ty' /\ Inv_ml_out_10_ok' /\ _ML2BR_sensor => Inv_il_out_10_ty'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _ML2BR_sensor, GRD_ML2BR_sensor, ACT_ML2BR_sensor, ML2BR_sensor

THEOREM PO_Next_IL2BR_sensor_il_out_10_ty == Invariant /\ Inv_ml_out_10_ty' /\ Inv_ml_out_10_ok' /\ _IL2BR_sensor => Inv_il_out_10_ty'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _IL2BR_sensor, GRD_IL2BR_sensor, ACT_IL2BR_sensor, IL2BR_sensor

THEOREM PO_Next_BR2ML_sensor_il_out_10_ty == Invariant /\ Inv_ml_out_10_ty' /\ Inv_ml_out_10_ok' /\ _BR2ML_sensor => Inv_il_out_10_ty'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _BR2ML_sensor, GRD_BR2ML_sensor, ACT_BR2ML_sensor, BR2ML_sensor

THEOREM PO_Next_BR2IL_sensor_il_out_10_ty == Invariant /\ Inv_ml_out_10_ty' /\ Inv_ml_out_10_ok' /\ _BR2IL_sensor => Inv_il_out_10_ty'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _BR2IL_sensor, GRD_BR2IL_sensor, ACT_BR2IL_sensor, BR2IL_sensor

THEOREM PO_Init_il_out_10_ty == Init => Inv_il_out_10_ty
PROOF
BY DEF Init, Inv_il_out_10_ty

THEOREM PO_Next_il_out_10_ty == Invariant /\ Next /\ Inv_ml_out_10_ty' /\ Inv_ml_out_10_ok' => Inv_il_out_10_ty'
PROOF
BY THEOREM PO_Next_ML2BR_il_out_10_ty, THEOREM PO_Next_BR2ML_il_out_10_ty, THEOREM PO_Next_BR2IL_il_out_10_ty, THEOREM PO_Next_IL2BR_il_out_10_ty, THEOREM PO_Next_ml_green_il_out_10_ty, THEOREM PO_Next_il_green_il_out_10_ty, THEOREM PO_Next_ML2BR_sensor_il_out_10_ty, THEOREM PO_Next_IL2BR_sensor_il_out_10_ty, THEOREM PO_Next_BR2ML_sensor_il_out_10_ty, THEOREM PO_Next_BR2IL_sensor_il_out_10_ty DEF Next

THEOREM PO_Next_ML2BR_il_out_10_ok == Invariant /\ Inv_ml_out_10_ty' /\ Inv_ml_out_10_ok' /\ Inv_il_out_10_ty' /\ _ML2BR => Inv_il_out_10_ok'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _ML2BR, GRD_ML2BR, ACT_ML2BR, ML2BR

THEOREM PO_Next_BR2ML_il_out_10_ok == Invariant /\ Inv_ml_out_10_ty' /\ Inv_ml_out_10_ok' /\ Inv_il_out_10_ty' /\ _BR2ML => Inv_il_out_10_ok'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _BR2ML, GRD_BR2ML, ACT_BR2ML, BR2ML

THEOREM PO_Next_BR2IL_il_out_10_ok == Invariant /\ Inv_ml_out_10_ty' /\ Inv_ml_out_10_ok' /\ Inv_il_out_10_ty' /\ _BR2IL => Inv_il_out_10_ok'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _BR2IL, GRD_BR2IL, ACT_BR2IL, BR2IL

THEOREM PO_Next_IL2BR_il_out_10_ok == Invariant /\ Inv_ml_out_10_ty' /\ Inv_ml_out_10_ok' /\ Inv_il_out_10_ty' /\ _IL2BR => Inv_il_out_10_ok'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _IL2BR, GRD_IL2BR, ACT_IL2BR, IL2BR

THEOREM PO_Next_ml_green_il_out_10_ok == Invariant /\ Inv_ml_out_10_ty' /\ Inv_ml_out_10_ok' /\ Inv_il_out_10_ty' /\ _ml_green => Inv_il_out_10_ok'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _ml_green, GRD_ml_green, ACT_ml_green, ml_green

THEOREM PO_Next_il_green_il_out_10_ok == Invariant /\ Inv_ml_out_10_ty' /\ Inv_ml_out_10_ok' /\ Inv_il_out_10_ty' /\ _il_green => Inv_il_out_10_ok'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _il_green, GRD_il_green, ACT_il_green, il_green

THEOREM PO_Next_ML2BR_sensor_il_out_10_ok == Invariant /\ Inv_ml_out_10_ty' /\ Inv_ml_out_10_ok' /\ Inv_il_out_10_ty' /\ _ML2BR_sensor => Inv_il_out_10_ok'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _ML2BR_sensor, GRD_ML2BR_sensor, ACT_ML2BR_sensor, ML2BR_sensor

THEOREM PO_Next_IL2BR_sensor_il_out_10_ok == Invariant /\ Inv_ml_out_10_ty' /\ Inv_ml_out_10_ok' /\ Inv_il_out_10_ty' /\ _IL2BR_sensor => Inv_il_out_10_ok'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _IL2BR_sensor, GRD_IL2BR_sensor, ACT_IL2BR_sensor, IL2BR_sensor

THEOREM PO_Next_BR2ML_sensor_il_out_10_ok == Invariant /\ Inv_ml_out_10_ty' /\ Inv_ml_out_10_ok' /\ Inv_il_out_10_ty' /\ _BR2ML_sensor => Inv_il_out_10_ok'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _BR2ML_sensor, GRD_BR2ML_sensor, ACT_BR2ML_sensor, BR2ML_sensor

THEOREM PO_Next_BR2IL_sensor_il_out_10_ok == Invariant /\ Inv_ml_out_10_ty' /\ Inv_ml_out_10_ok' /\ Inv_il_out_10_ty' /\ _BR2IL_sensor => Inv_il_out_10_ok'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _BR2IL_sensor, GRD_BR2IL_sensor, ACT_BR2IL_sensor, BR2IL_sensor

THEOREM PO_Init_il_out_10_ok == Init => Inv_il_out_10_ok
PROOF
BY DEF Init, Inv_il_out_10_ok

THEOREM PO_Next_il_out_10_ok == Invariant /\ Next /\ Inv_ml_out_10_ty' /\ Inv_ml_out_10_ok' /\ Inv_il_out_10_ty' => Inv_il_out_10_ok'
PROOF
BY THEOREM PO_Next_ML2BR_il_out_10_ok, THEOREM PO_Next_BR2ML_il_out_10_ok, THEOREM PO_Next_BR2IL_il_out_10_ok, THEOREM PO_Next_IL2BR_il_out_10_ok, THEOREM PO_Next_ml_green_il_out_10_ok, THEOREM PO_Next_il_green_il_out_10_ok, THEOREM PO_Next_ML2BR_sensor_il_out_10_ok, THEOREM PO_Next_IL2BR_sensor_il_out_10_ok, THEOREM PO_Next_BR2ML_sensor_il_out_10_ok, THEOREM PO_Next_BR2IL_sensor_il_out_10_ok DEF Next

THEOREM PO_Next_ML2BR_ml_in_10_ty == Invariant /\ Inv_ml_out_10_ty' /\ Inv_ml_out_10_ok' /\ Inv_il_out_10_ty' /\ Inv_il_out_10_ok' /\ _ML2BR => Inv_ml_in_10_ty'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _ML2BR, GRD_ML2BR, ACT_ML2BR, ML2BR

THEOREM PO_Next_BR2ML_ml_in_10_ty == Invariant /\ Inv_ml_out_10_ty' /\ Inv_ml_out_10_ok' /\ Inv_il_out_10_ty' /\ Inv_il_out_10_ok' /\ _BR2ML => Inv_ml_in_10_ty'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _BR2ML, GRD_BR2ML, ACT_BR2ML, BR2ML

THEOREM PO_Next_BR2IL_ml_in_10_ty == Invariant /\ Inv_ml_out_10_ty' /\ Inv_ml_out_10_ok' /\ Inv_il_out_10_ty' /\ Inv_il_out_10_ok' /\ _BR2IL => Inv_ml_in_10_ty'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _BR2IL, GRD_BR2IL, ACT_BR2IL, BR2IL

THEOREM PO_Next_IL2BR_ml_in_10_ty == Invariant /\ Inv_ml_out_10_ty' /\ Inv_ml_out_10_ok' /\ Inv_il_out_10_ty' /\ Inv_il_out_10_ok' /\ _IL2BR => Inv_ml_in_10_ty'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _IL2BR, GRD_IL2BR, ACT_IL2BR, IL2BR

THEOREM PO_Next_ml_green_ml_in_10_ty == Invariant /\ Inv_ml_out_10_ty' /\ Inv_ml_out_10_ok' /\ Inv_il_out_10_ty' /\ Inv_il_out_10_ok' /\ _ml_green => Inv_ml_in_10_ty'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _ml_green, GRD_ml_green, ACT_ml_green, ml_green

THEOREM PO_Next_il_green_ml_in_10_ty == Invariant /\ Inv_ml_out_10_ty' /\ Inv_ml_out_10_ok' /\ Inv_il_out_10_ty' /\ Inv_il_out_10_ok' /\ _il_green => Inv_ml_in_10_ty'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _il_green, GRD_il_green, ACT_il_green, il_green

THEOREM PO_Next_ML2BR_sensor_ml_in_10_ty == Invariant /\ Inv_ml_out_10_ty' /\ Inv_ml_out_10_ok' /\ Inv_il_out_10_ty' /\ Inv_il_out_10_ok' /\ _ML2BR_sensor => Inv_ml_in_10_ty'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _ML2BR_sensor, GRD_ML2BR_sensor, ACT_ML2BR_sensor, ML2BR_sensor

THEOREM PO_Next_IL2BR_sensor_ml_in_10_ty == Invariant /\ Inv_ml_out_10_ty' /\ Inv_ml_out_10_ok' /\ Inv_il_out_10_ty' /\ Inv_il_out_10_ok' /\ _IL2BR_sensor => Inv_ml_in_10_ty'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _IL2BR_sensor, GRD_IL2BR_sensor, ACT_IL2BR_sensor, IL2BR_sensor

THEOREM PO_Next_BR2ML_sensor_ml_in_10_ty == Invariant /\ Inv_ml_out_10_ty' /\ Inv_ml_out_10_ok' /\ Inv_il_out_10_ty' /\ Inv_il_out_10_ok' /\ _BR2ML_sensor => Inv_ml_in_10_ty'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _BR2ML_sensor, GRD_BR2ML_sensor, ACT_BR2ML_sensor, BR2ML_sensor

THEOREM PO_Next_BR2IL_sensor_ml_in_10_ty == Invariant /\ Inv_ml_out_10_ty' /\ Inv_ml_out_10_ok' /\ Inv_il_out_10_ty' /\ Inv_il_out_10_ok' /\ _BR2IL_sensor => Inv_ml_in_10_ty'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _BR2IL_sensor, GRD_BR2IL_sensor, ACT_BR2IL_sensor, BR2IL_sensor

THEOREM PO_Init_ml_in_10_ty == Init => Inv_ml_in_10_ty
PROOF
BY DEF Init, Inv_ml_in_10_ty

THEOREM PO_Next_ml_in_10_ty == Invariant /\ Next /\ Inv_ml_out_10_ty' /\ Inv_ml_out_10_ok' /\ Inv_il_out_10_ty' /\ Inv_il_out_10_ok' => Inv_ml_in_10_ty'
PROOF
BY THEOREM PO_Next_ML2BR_ml_in_10_ty, THEOREM PO_Next_BR2ML_ml_in_10_ty, THEOREM PO_Next_BR2IL_ml_in_10_ty, THEOREM PO_Next_IL2BR_ml_in_10_ty, THEOREM PO_Next_ml_green_ml_in_10_ty, THEOREM PO_Next_il_green_ml_in_10_ty, THEOREM PO_Next_ML2BR_sensor_ml_in_10_ty, THEOREM PO_Next_IL2BR_sensor_ml_in_10_ty, THEOREM PO_Next_BR2ML_sensor_ml_in_10_ty, THEOREM PO_Next_BR2IL_sensor_ml_in_10_ty DEF Next

THEOREM PO_Next_ML2BR_il_in_10_ty == Invariant /\ Inv_ml_out_10_ty' /\ Inv_ml_out_10_ok' /\ Inv_il_out_10_ty' /\ Inv_il_out_10_ok' /\ Inv_ml_in_10_ty' /\ _ML2BR => Inv_il_in_10_ty'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _ML2BR, GRD_ML2BR, ACT_ML2BR, ML2BR

THEOREM PO_Next_BR2ML_il_in_10_ty == Invariant /\ Inv_ml_out_10_ty' /\ Inv_ml_out_10_ok' /\ Inv_il_out_10_ty' /\ Inv_il_out_10_ok' /\ Inv_ml_in_10_ty' /\ _BR2ML => Inv_il_in_10_ty'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _BR2ML, GRD_BR2ML, ACT_BR2ML, BR2ML

THEOREM PO_Next_BR2IL_il_in_10_ty == Invariant /\ Inv_ml_out_10_ty' /\ Inv_ml_out_10_ok' /\ Inv_il_out_10_ty' /\ Inv_il_out_10_ok' /\ Inv_ml_in_10_ty' /\ _BR2IL => Inv_il_in_10_ty'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _BR2IL, GRD_BR2IL, ACT_BR2IL, BR2IL

THEOREM PO_Next_IL2BR_il_in_10_ty == Invariant /\ Inv_ml_out_10_ty' /\ Inv_ml_out_10_ok' /\ Inv_il_out_10_ty' /\ Inv_il_out_10_ok' /\ Inv_ml_in_10_ty' /\ _IL2BR => Inv_il_in_10_ty'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _IL2BR, GRD_IL2BR, ACT_IL2BR, IL2BR

THEOREM PO_Next_ml_green_il_in_10_ty == Invariant /\ Inv_ml_out_10_ty' /\ Inv_ml_out_10_ok' /\ Inv_il_out_10_ty' /\ Inv_il_out_10_ok' /\ Inv_ml_in_10_ty' /\ _ml_green => Inv_il_in_10_ty'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _ml_green, GRD_ml_green, ACT_ml_green, ml_green

THEOREM PO_Next_il_green_il_in_10_ty == Invariant /\ Inv_ml_out_10_ty' /\ Inv_ml_out_10_ok' /\ Inv_il_out_10_ty' /\ Inv_il_out_10_ok' /\ Inv_ml_in_10_ty' /\ _il_green => Inv_il_in_10_ty'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _il_green, GRD_il_green, ACT_il_green, il_green

THEOREM PO_Next_ML2BR_sensor_il_in_10_ty == Invariant /\ Inv_ml_out_10_ty' /\ Inv_ml_out_10_ok' /\ Inv_il_out_10_ty' /\ Inv_il_out_10_ok' /\ Inv_ml_in_10_ty' /\ _ML2BR_sensor => Inv_il_in_10_ty'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _ML2BR_sensor, GRD_ML2BR_sensor, ACT_ML2BR_sensor, ML2BR_sensor

THEOREM PO_Next_IL2BR_sensor_il_in_10_ty == Invariant /\ Inv_ml_out_10_ty' /\ Inv_ml_out_10_ok' /\ Inv_il_out_10_ty' /\ Inv_il_out_10_ok' /\ Inv_ml_in_10_ty' /\ _IL2BR_sensor => Inv_il_in_10_ty'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _IL2BR_sensor, GRD_IL2BR_sensor, ACT_IL2BR_sensor, IL2BR_sensor

THEOREM PO_Next_BR2ML_sensor_il_in_10_ty == Invariant /\ Inv_ml_out_10_ty' /\ Inv_ml_out_10_ok' /\ Inv_il_out_10_ty' /\ Inv_il_out_10_ok' /\ Inv_ml_in_10_ty' /\ _BR2ML_sensor => Inv_il_in_10_ty'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _BR2ML_sensor, GRD_BR2ML_sensor, ACT_BR2ML_sensor, BR2ML_sensor

THEOREM PO_Next_BR2IL_sensor_il_in_10_ty == Invariant /\ Inv_ml_out_10_ty' /\ Inv_ml_out_10_ok' /\ Inv_il_out_10_ty' /\ Inv_il_out_10_ok' /\ Inv_ml_in_10_ty' /\ _BR2IL_sensor => Inv_il_in_10_ty'
PROOF
BY DEF Invariant, Inv_ml_out_10_ty, Inv_ml_out_10_ok, Inv_il_out_10_ty, Inv_il_out_10_ok, Inv_ml_in_10_ty, Inv_il_in_10_ty, _BR2IL_sensor, GRD_BR2IL_sensor, ACT_BR2IL_sensor, BR2IL_sensor

THEOREM PO_Init_il_in_10_ty == Init => Inv_il_in_10_ty
PROOF
BY DEF Init, Inv_il_in_10_ty

THEOREM PO_Next_il_in_10_ty == Invariant /\ Next /\ Inv_ml_out_10_ty' /\ Inv_ml_out_10_ok' /\ Inv_il_out_10_ty' /\ Inv_il_out_10_ok' /\ Inv_ml_in_10_ty' => Inv_il_in_10_ty'
PROOF
BY THEOREM PO_Next_ML2BR_il_in_10_ty, THEOREM PO_Next_BR2ML_il_in_10_ty, THEOREM PO_Next_BR2IL_il_in_10_ty, THEOREM PO_Next_IL2BR_il_in_10_ty, THEOREM PO_Next_ml_green_il_in_10_ty, THEOREM PO_Next_il_green_il_in_10_ty, THEOREM PO_Next_ML2BR_sensor_il_in_10_ty, THEOREM PO_Next_IL2BR_sensor_il_in_10_ty, THEOREM PO_Next_BR2ML_sensor_il_in_10_ty, THEOREM PO_Next_BR2IL_sensor_il_in_10_ty DEF Next


THEOREM InvariantIsPreserved == Invariant /\ Next => Invariant'
PROOF
BY THEOREM PO_Next_ml_out_10_ty, THEOREM PO_Next_ml_out_10_ok, THEOREM PO_Next_il_out_10_ty, THEOREM PO_Next_il_out_10_ok, THEOREM PO_Next_ml_in_10_ty, THEOREM PO_Next_il_in_10_ty DEF Invariant

THEOREM NoDeadlock == Invariant => 
	\/ GRD_ML2BR
	\/ GRD_BR2ML
	\/ GRD_BR2IL
	\/ GRD_IL2BR
	\/ GRD_ml_green
	\/ GRD_il_green
	\/ GRD_ML2BR_sensor
	\/ GRD_IL2BR_sensor
	\/ GRD_BR2ML_sensor
	\/ GRD_BR2IL_sensor
PROOF
	BY DEF GRD_ML2BR,GRD_BR2ML,GRD_BR2IL,GRD_IL2BR,GRD_ml_green,GRD_il_green,GRD_ML2BR_sensor,GRD_IL2BR_sensor,GRD_BR2ML_sensor,GRD_BR2IL_sensor, Invariant,Inv_ml_out_10_ty,Inv_ml_out_10_ok,Inv_il_out_10_ty,Inv_il_out_10_ok,Inv_ml_in_10_ty,Inv_il_in_10_ty
========================================
