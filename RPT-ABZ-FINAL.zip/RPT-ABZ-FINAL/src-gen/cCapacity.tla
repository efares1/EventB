---- MODULE cCapacity ----
EXTENDS Naturals, Sequences, FiniteSets, moreRelations
CONSTANTS capacity
(*  capacity ∈ ℕ1 *)
ASSUME cap == (capacity \in (Nat \ {0}))
====
