let  cCapacity = {
	name = "cCapacity";
	extends = [];
	sets = [];
	constants = ["capacity"];
	axioms = [{name = "cap"; predicate = " capacity ∈ ℕ1"}]
}
