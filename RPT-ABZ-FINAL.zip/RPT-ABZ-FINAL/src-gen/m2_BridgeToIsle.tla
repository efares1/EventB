(*
machine m2_BridgeToIsle refines m1_IsleCapacity
variables
	entering
	islecars
	exiting
	cars
invariants
	@entering_ty entering ∈ ℤ
	@islecars_ty islecars ∈ ℤ
	@exiting_ty exiting ∈ ℤ
	@exclusivity  entering = 0 ∨ exiting = 0
	@enter_ctr  entering ≥ 0
	@stay_ctr  islecars ≥ 0
	@exit_ctr  exiting ≥ 0
	@glueing  cars = entering + islecars + exiting
events
	event INITIALISATION extends INITIALISATION
	then
		@entering entering ≔ 0
		@islecars islecars ≔ 0
		@exiting exiting ≔ 0
	end
	event ML2BR extends ML2BR
	when 
		@exclusivity exiting=0
	then
		@entering entering ≔ entering+1
	end
	event BR2ML extends BR2ML
	when 
		@exclusivity entering=0∨exiting − 1=0
		@exit_ctr exiting − 1≥0
	then
		@exiting exiting ≔ exiting−1
	end
	event BR2IL
	when 
		@exclusivity entering − 1=0∨exiting=0
		@enter_ctr entering − 1≥0
	then
		@islecars islecars ≔ islecars+1
		@entering entering ≔ entering−1
	end
	event IL2BR
	when 
		@exclusivity entering=0
		@stay_ctr islecars − 1≥0
	then
		@exiting exiting ≔ exiting+1
		@islecars islecars ≔ islecars−1
	end
end
*)
------- MODULE m2_BridgeToIsle -------
EXTENDS Integers, TLAPS
VARIABLES
	event, entering, islecars, exiting, cars
vars == <<event, entering, islecars, exiting, cars>>
Inv_entering_ty == (entering \in Int)
Inv_islecars_ty == (islecars \in Int)
Inv_exiting_ty == (exiting \in Int)
Inv_exclusivity == ((entering = 0) \/  (exiting = 0) )
Inv_enter_ctr == (entering >= 0)
Inv_stay_ctr == (islecars >= 0)
Inv_exit_ctr == (exiting >= 0)
Inv_glueing == (cars = ((entering+islecars)+exiting))

Invariant ==
	/\ Inv_entering_ty
	/\ Inv_islecars_ty
	/\ Inv_exiting_ty
	/\ Inv_exclusivity
	/\ Inv_enter_ctr
	/\ Inv_stay_ctr
	/\ Inv_exit_ctr
	/\ Inv_glueing

Init == 
	/\ event = <<"INITIALISATION">>
	/\ <<entering>> = <<0>>
	/\ <<islecars>> = <<0>>
	/\ <<exiting>> = <<0>>
ML2BR  == event = <<"ML2BR">>
GRD_ML2BR ==
	/\ (exiting = 0)
ACT_ML2BR ==
	/\ <<entering'>> = <<(entering+1)>>
	/\ UNCHANGED(<<islecars,exiting,cars>>)
_ML2BR  ==
	/\ ML2BR'
	/\ GRD_ML2BR
	/\ ACT_ML2BR
BR2ML  == event = <<"BR2ML">>
GRD_BR2ML ==
	/\ ((entering = 0) \/  ((exiting - 1) = 0) )
	/\ ((exiting - 1) >= 0)
ACT_BR2ML ==
	/\ <<exiting'>> = <<(exiting - 1)>>
	/\ UNCHANGED(<<entering,islecars,cars>>)
_BR2ML  ==
	/\ BR2ML'
	/\ GRD_BR2ML
	/\ ACT_BR2ML
BR2IL  == event = <<"BR2IL">>
GRD_BR2IL ==
	/\ (((entering - 1) = 0) \/  (exiting = 0) )
	/\ ((entering - 1) >= 0)
ACT_BR2IL ==
	/\ <<islecars'>> = <<(islecars+1)>>
	/\ <<entering'>> = <<(entering - 1)>>
	/\ UNCHANGED(<<exiting,cars>>)
_BR2IL  ==
	/\ BR2IL'
	/\ GRD_BR2IL
	/\ ACT_BR2IL
IL2BR  == event = <<"IL2BR">>
GRD_IL2BR ==
	/\ (entering = 0)
	/\ ((islecars - 1) >= 0)
ACT_IL2BR ==
	/\ <<exiting'>> = <<(exiting+1)>>
	/\ <<islecars'>> = <<(islecars - 1)>>
	/\ UNCHANGED(<<entering,cars>>)
_IL2BR  ==
	/\ IL2BR'
	/\ GRD_IL2BR
	/\ ACT_IL2BR

Next ==
	\/ _ML2BR
	\/ _BR2ML
	\/ _BR2IL
	\/ _IL2BR

Spec == Init /\ [][Next]_vars
THEOREM PO_Next_ML2BR_entering_ty == Invariant /\ _ML2BR => Inv_entering_ty'
PROOF
BY DEF Invariant, Inv_entering_ty, Inv_islecars_ty, Inv_exiting_ty, Inv_exclusivity, Inv_enter_ctr, Inv_stay_ctr, Inv_exit_ctr, Inv_glueing, _ML2BR, GRD_ML2BR, ACT_ML2BR, ML2BR

THEOREM PO_Next_BR2ML_entering_ty == Invariant /\ _BR2ML => Inv_entering_ty'
PROOF
BY DEF Invariant, Inv_entering_ty, Inv_islecars_ty, Inv_exiting_ty, Inv_exclusivity, Inv_enter_ctr, Inv_stay_ctr, Inv_exit_ctr, Inv_glueing, _BR2ML, GRD_BR2ML, ACT_BR2ML, BR2ML

THEOREM PO_Next_BR2IL_entering_ty == Invariant /\ _BR2IL => Inv_entering_ty'
PROOF
BY DEF Invariant, Inv_entering_ty, Inv_islecars_ty, Inv_exiting_ty, Inv_exclusivity, Inv_enter_ctr, Inv_stay_ctr, Inv_exit_ctr, Inv_glueing, _BR2IL, GRD_BR2IL, ACT_BR2IL, BR2IL

THEOREM PO_Next_IL2BR_entering_ty == Invariant /\ _IL2BR => Inv_entering_ty'
PROOF
BY DEF Invariant, Inv_entering_ty, Inv_islecars_ty, Inv_exiting_ty, Inv_exclusivity, Inv_enter_ctr, Inv_stay_ctr, Inv_exit_ctr, Inv_glueing, _IL2BR, GRD_IL2BR, ACT_IL2BR, IL2BR

THEOREM PO_Init_entering_ty == Init => Inv_entering_ty
PROOF
BY DEF Init, Inv_entering_ty

THEOREM PO_Next_entering_ty == Invariant /\ Next => Inv_entering_ty'
PROOF
BY THEOREM PO_Next_ML2BR_entering_ty, THEOREM PO_Next_BR2ML_entering_ty, THEOREM PO_Next_BR2IL_entering_ty, THEOREM PO_Next_IL2BR_entering_ty DEF Next

THEOREM PO_Next_ML2BR_islecars_ty == Invariant /\ Inv_entering_ty' /\ _ML2BR => Inv_islecars_ty'
PROOF
BY DEF Invariant, Inv_entering_ty, Inv_islecars_ty, Inv_exiting_ty, Inv_exclusivity, Inv_enter_ctr, Inv_stay_ctr, Inv_exit_ctr, Inv_glueing, _ML2BR, GRD_ML2BR, ACT_ML2BR, ML2BR

THEOREM PO_Next_BR2ML_islecars_ty == Invariant /\ Inv_entering_ty' /\ _BR2ML => Inv_islecars_ty'
PROOF
BY DEF Invariant, Inv_entering_ty, Inv_islecars_ty, Inv_exiting_ty, Inv_exclusivity, Inv_enter_ctr, Inv_stay_ctr, Inv_exit_ctr, Inv_glueing, _BR2ML, GRD_BR2ML, ACT_BR2ML, BR2ML

THEOREM PO_Next_BR2IL_islecars_ty == Invariant /\ Inv_entering_ty' /\ _BR2IL => Inv_islecars_ty'
PROOF
BY DEF Invariant, Inv_entering_ty, Inv_islecars_ty, Inv_exiting_ty, Inv_exclusivity, Inv_enter_ctr, Inv_stay_ctr, Inv_exit_ctr, Inv_glueing, _BR2IL, GRD_BR2IL, ACT_BR2IL, BR2IL

THEOREM PO_Next_IL2BR_islecars_ty == Invariant /\ Inv_entering_ty' /\ _IL2BR => Inv_islecars_ty'
PROOF
BY DEF Invariant, Inv_entering_ty, Inv_islecars_ty, Inv_exiting_ty, Inv_exclusivity, Inv_enter_ctr, Inv_stay_ctr, Inv_exit_ctr, Inv_glueing, _IL2BR, GRD_IL2BR, ACT_IL2BR, IL2BR

THEOREM PO_Init_islecars_ty == Init => Inv_islecars_ty
PROOF
BY DEF Init, Inv_islecars_ty

THEOREM PO_Next_islecars_ty == Invariant /\ Next /\ Inv_entering_ty' => Inv_islecars_ty'
PROOF
BY THEOREM PO_Next_ML2BR_islecars_ty, THEOREM PO_Next_BR2ML_islecars_ty, THEOREM PO_Next_BR2IL_islecars_ty, THEOREM PO_Next_IL2BR_islecars_ty DEF Next

THEOREM PO_Next_ML2BR_exiting_ty == Invariant /\ Inv_entering_ty' /\ Inv_islecars_ty' /\ _ML2BR => Inv_exiting_ty'
PROOF
BY DEF Invariant, Inv_entering_ty, Inv_islecars_ty, Inv_exiting_ty, Inv_exclusivity, Inv_enter_ctr, Inv_stay_ctr, Inv_exit_ctr, Inv_glueing, _ML2BR, GRD_ML2BR, ACT_ML2BR, ML2BR

THEOREM PO_Next_BR2ML_exiting_ty == Invariant /\ Inv_entering_ty' /\ Inv_islecars_ty' /\ _BR2ML => Inv_exiting_ty'
PROOF
BY DEF Invariant, Inv_entering_ty, Inv_islecars_ty, Inv_exiting_ty, Inv_exclusivity, Inv_enter_ctr, Inv_stay_ctr, Inv_exit_ctr, Inv_glueing, _BR2ML, GRD_BR2ML, ACT_BR2ML, BR2ML

THEOREM PO_Next_BR2IL_exiting_ty == Invariant /\ Inv_entering_ty' /\ Inv_islecars_ty' /\ _BR2IL => Inv_exiting_ty'
PROOF
BY DEF Invariant, Inv_entering_ty, Inv_islecars_ty, Inv_exiting_ty, Inv_exclusivity, Inv_enter_ctr, Inv_stay_ctr, Inv_exit_ctr, Inv_glueing, _BR2IL, GRD_BR2IL, ACT_BR2IL, BR2IL

THEOREM PO_Next_IL2BR_exiting_ty == Invariant /\ Inv_entering_ty' /\ Inv_islecars_ty' /\ _IL2BR => Inv_exiting_ty'
PROOF
BY DEF Invariant, Inv_entering_ty, Inv_islecars_ty, Inv_exiting_ty, Inv_exclusivity, Inv_enter_ctr, Inv_stay_ctr, Inv_exit_ctr, Inv_glueing, _IL2BR, GRD_IL2BR, ACT_IL2BR, IL2BR

THEOREM PO_Init_exiting_ty == Init => Inv_exiting_ty
PROOF
BY DEF Init, Inv_exiting_ty

THEOREM PO_Next_exiting_ty == Invariant /\ Next /\ Inv_entering_ty' /\ Inv_islecars_ty' => Inv_exiting_ty'
PROOF
BY THEOREM PO_Next_ML2BR_exiting_ty, THEOREM PO_Next_BR2ML_exiting_ty, THEOREM PO_Next_BR2IL_exiting_ty, THEOREM PO_Next_IL2BR_exiting_ty DEF Next

THEOREM PO_Next_ML2BR_exclusivity == Invariant /\ Inv_entering_ty' /\ Inv_islecars_ty' /\ Inv_exiting_ty' /\ _ML2BR => Inv_exclusivity'
PROOF
BY DEF Invariant, Inv_entering_ty, Inv_islecars_ty, Inv_exiting_ty, Inv_exclusivity, Inv_enter_ctr, Inv_stay_ctr, Inv_exit_ctr, Inv_glueing, _ML2BR, GRD_ML2BR, ACT_ML2BR, ML2BR

THEOREM PO_Next_BR2ML_exclusivity == Invariant /\ Inv_entering_ty' /\ Inv_islecars_ty' /\ Inv_exiting_ty' /\ _BR2ML => Inv_exclusivity'
PROOF
BY DEF Invariant, Inv_entering_ty, Inv_islecars_ty, Inv_exiting_ty, Inv_exclusivity, Inv_enter_ctr, Inv_stay_ctr, Inv_exit_ctr, Inv_glueing, _BR2ML, GRD_BR2ML, ACT_BR2ML, BR2ML

THEOREM PO_Next_BR2IL_exclusivity == Invariant /\ Inv_entering_ty' /\ Inv_islecars_ty' /\ Inv_exiting_ty' /\ _BR2IL => Inv_exclusivity'
PROOF
BY DEF Invariant, Inv_entering_ty, Inv_islecars_ty, Inv_exiting_ty, Inv_exclusivity, Inv_enter_ctr, Inv_stay_ctr, Inv_exit_ctr, Inv_glueing, _BR2IL, GRD_BR2IL, ACT_BR2IL, BR2IL

THEOREM PO_Next_IL2BR_exclusivity == Invariant /\ Inv_entering_ty' /\ Inv_islecars_ty' /\ Inv_exiting_ty' /\ _IL2BR => Inv_exclusivity'
PROOF
BY DEF Invariant, Inv_entering_ty, Inv_islecars_ty, Inv_exiting_ty, Inv_exclusivity, Inv_enter_ctr, Inv_stay_ctr, Inv_exit_ctr, Inv_glueing, _IL2BR, GRD_IL2BR, ACT_IL2BR, IL2BR

THEOREM PO_Init_exclusivity == Init => Inv_exclusivity
PROOF
BY DEF Init, Inv_exclusivity

THEOREM PO_Next_exclusivity == Invariant /\ Next /\ Inv_entering_ty' /\ Inv_islecars_ty' /\ Inv_exiting_ty' => Inv_exclusivity'
PROOF
BY THEOREM PO_Next_ML2BR_exclusivity, THEOREM PO_Next_BR2ML_exclusivity, THEOREM PO_Next_BR2IL_exclusivity, THEOREM PO_Next_IL2BR_exclusivity DEF Next

THEOREM PO_Next_ML2BR_enter_ctr == Invariant /\ Inv_entering_ty' /\ Inv_islecars_ty' /\ Inv_exiting_ty' /\ Inv_exclusivity' /\ _ML2BR => Inv_enter_ctr'
PROOF
BY DEF Invariant, Inv_entering_ty, Inv_islecars_ty, Inv_exiting_ty, Inv_exclusivity, Inv_enter_ctr, Inv_stay_ctr, Inv_exit_ctr, Inv_glueing, _ML2BR, GRD_ML2BR, ACT_ML2BR, ML2BR

THEOREM PO_Next_BR2ML_enter_ctr == Invariant /\ Inv_entering_ty' /\ Inv_islecars_ty' /\ Inv_exiting_ty' /\ Inv_exclusivity' /\ _BR2ML => Inv_enter_ctr'
PROOF
BY DEF Invariant, Inv_entering_ty, Inv_islecars_ty, Inv_exiting_ty, Inv_exclusivity, Inv_enter_ctr, Inv_stay_ctr, Inv_exit_ctr, Inv_glueing, _BR2ML, GRD_BR2ML, ACT_BR2ML, BR2ML

THEOREM PO_Next_BR2IL_enter_ctr == Invariant /\ Inv_entering_ty' /\ Inv_islecars_ty' /\ Inv_exiting_ty' /\ Inv_exclusivity' /\ _BR2IL => Inv_enter_ctr'
PROOF
BY DEF Invariant, Inv_entering_ty, Inv_islecars_ty, Inv_exiting_ty, Inv_exclusivity, Inv_enter_ctr, Inv_stay_ctr, Inv_exit_ctr, Inv_glueing, _BR2IL, GRD_BR2IL, ACT_BR2IL, BR2IL

THEOREM PO_Next_IL2BR_enter_ctr == Invariant /\ Inv_entering_ty' /\ Inv_islecars_ty' /\ Inv_exiting_ty' /\ Inv_exclusivity' /\ _IL2BR => Inv_enter_ctr'
PROOF
BY DEF Invariant, Inv_entering_ty, Inv_islecars_ty, Inv_exiting_ty, Inv_exclusivity, Inv_enter_ctr, Inv_stay_ctr, Inv_exit_ctr, Inv_glueing, _IL2BR, GRD_IL2BR, ACT_IL2BR, IL2BR

THEOREM PO_Init_enter_ctr == Init => Inv_enter_ctr
PROOF
BY DEF Init, Inv_enter_ctr

THEOREM PO_Next_enter_ctr == Invariant /\ Next /\ Inv_entering_ty' /\ Inv_islecars_ty' /\ Inv_exiting_ty' /\ Inv_exclusivity' => Inv_enter_ctr'
PROOF
BY THEOREM PO_Next_ML2BR_enter_ctr, THEOREM PO_Next_BR2ML_enter_ctr, THEOREM PO_Next_BR2IL_enter_ctr, THEOREM PO_Next_IL2BR_enter_ctr DEF Next

THEOREM PO_Next_ML2BR_stay_ctr == Invariant /\ Inv_entering_ty' /\ Inv_islecars_ty' /\ Inv_exiting_ty' /\ Inv_exclusivity' /\ Inv_enter_ctr' /\ _ML2BR => Inv_stay_ctr'
PROOF
BY DEF Invariant, Inv_entering_ty, Inv_islecars_ty, Inv_exiting_ty, Inv_exclusivity, Inv_enter_ctr, Inv_stay_ctr, Inv_exit_ctr, Inv_glueing, _ML2BR, GRD_ML2BR, ACT_ML2BR, ML2BR

THEOREM PO_Next_BR2ML_stay_ctr == Invariant /\ Inv_entering_ty' /\ Inv_islecars_ty' /\ Inv_exiting_ty' /\ Inv_exclusivity' /\ Inv_enter_ctr' /\ _BR2ML => Inv_stay_ctr'
PROOF
BY DEF Invariant, Inv_entering_ty, Inv_islecars_ty, Inv_exiting_ty, Inv_exclusivity, Inv_enter_ctr, Inv_stay_ctr, Inv_exit_ctr, Inv_glueing, _BR2ML, GRD_BR2ML, ACT_BR2ML, BR2ML

THEOREM PO_Next_BR2IL_stay_ctr == Invariant /\ Inv_entering_ty' /\ Inv_islecars_ty' /\ Inv_exiting_ty' /\ Inv_exclusivity' /\ Inv_enter_ctr' /\ _BR2IL => Inv_stay_ctr'
PROOF
BY DEF Invariant, Inv_entering_ty, Inv_islecars_ty, Inv_exiting_ty, Inv_exclusivity, Inv_enter_ctr, Inv_stay_ctr, Inv_exit_ctr, Inv_glueing, _BR2IL, GRD_BR2IL, ACT_BR2IL, BR2IL

THEOREM PO_Next_IL2BR_stay_ctr == Invariant /\ Inv_entering_ty' /\ Inv_islecars_ty' /\ Inv_exiting_ty' /\ Inv_exclusivity' /\ Inv_enter_ctr' /\ _IL2BR => Inv_stay_ctr'
PROOF
BY DEF Invariant, Inv_entering_ty, Inv_islecars_ty, Inv_exiting_ty, Inv_exclusivity, Inv_enter_ctr, Inv_stay_ctr, Inv_exit_ctr, Inv_glueing, _IL2BR, GRD_IL2BR, ACT_IL2BR, IL2BR

THEOREM PO_Init_stay_ctr == Init => Inv_stay_ctr
PROOF
BY DEF Init, Inv_stay_ctr

THEOREM PO_Next_stay_ctr == Invariant /\ Next /\ Inv_entering_ty' /\ Inv_islecars_ty' /\ Inv_exiting_ty' /\ Inv_exclusivity' /\ Inv_enter_ctr' => Inv_stay_ctr'
PROOF
BY THEOREM PO_Next_ML2BR_stay_ctr, THEOREM PO_Next_BR2ML_stay_ctr, THEOREM PO_Next_BR2IL_stay_ctr, THEOREM PO_Next_IL2BR_stay_ctr DEF Next

THEOREM PO_Next_ML2BR_exit_ctr == Invariant /\ Inv_entering_ty' /\ Inv_islecars_ty' /\ Inv_exiting_ty' /\ Inv_exclusivity' /\ Inv_enter_ctr' /\ Inv_stay_ctr' /\ _ML2BR => Inv_exit_ctr'
PROOF
BY DEF Invariant, Inv_entering_ty, Inv_islecars_ty, Inv_exiting_ty, Inv_exclusivity, Inv_enter_ctr, Inv_stay_ctr, Inv_exit_ctr, Inv_glueing, _ML2BR, GRD_ML2BR, ACT_ML2BR, ML2BR

THEOREM PO_Next_BR2ML_exit_ctr == Invariant /\ Inv_entering_ty' /\ Inv_islecars_ty' /\ Inv_exiting_ty' /\ Inv_exclusivity' /\ Inv_enter_ctr' /\ Inv_stay_ctr' /\ _BR2ML => Inv_exit_ctr'
PROOF
BY DEF Invariant, Inv_entering_ty, Inv_islecars_ty, Inv_exiting_ty, Inv_exclusivity, Inv_enter_ctr, Inv_stay_ctr, Inv_exit_ctr, Inv_glueing, _BR2ML, GRD_BR2ML, ACT_BR2ML, BR2ML

THEOREM PO_Next_BR2IL_exit_ctr == Invariant /\ Inv_entering_ty' /\ Inv_islecars_ty' /\ Inv_exiting_ty' /\ Inv_exclusivity' /\ Inv_enter_ctr' /\ Inv_stay_ctr' /\ _BR2IL => Inv_exit_ctr'
PROOF
BY DEF Invariant, Inv_entering_ty, Inv_islecars_ty, Inv_exiting_ty, Inv_exclusivity, Inv_enter_ctr, Inv_stay_ctr, Inv_exit_ctr, Inv_glueing, _BR2IL, GRD_BR2IL, ACT_BR2IL, BR2IL

THEOREM PO_Next_IL2BR_exit_ctr == Invariant /\ Inv_entering_ty' /\ Inv_islecars_ty' /\ Inv_exiting_ty' /\ Inv_exclusivity' /\ Inv_enter_ctr' /\ Inv_stay_ctr' /\ _IL2BR => Inv_exit_ctr'
PROOF
BY DEF Invariant, Inv_entering_ty, Inv_islecars_ty, Inv_exiting_ty, Inv_exclusivity, Inv_enter_ctr, Inv_stay_ctr, Inv_exit_ctr, Inv_glueing, _IL2BR, GRD_IL2BR, ACT_IL2BR, IL2BR

THEOREM PO_Init_exit_ctr == Init => Inv_exit_ctr
PROOF
BY DEF Init, Inv_exit_ctr

THEOREM PO_Next_exit_ctr == Invariant /\ Next /\ Inv_entering_ty' /\ Inv_islecars_ty' /\ Inv_exiting_ty' /\ Inv_exclusivity' /\ Inv_enter_ctr' /\ Inv_stay_ctr' => Inv_exit_ctr'
PROOF
BY THEOREM PO_Next_ML2BR_exit_ctr, THEOREM PO_Next_BR2ML_exit_ctr, THEOREM PO_Next_BR2IL_exit_ctr, THEOREM PO_Next_IL2BR_exit_ctr DEF Next

THEOREM PO_Next_ML2BR_glueing == Invariant /\ Inv_entering_ty' /\ Inv_islecars_ty' /\ Inv_exiting_ty' /\ Inv_exclusivity' /\ Inv_enter_ctr' /\ Inv_stay_ctr' /\ Inv_exit_ctr' /\ _ML2BR => Inv_glueing'
PROOF
BY DEF Invariant, Inv_entering_ty, Inv_islecars_ty, Inv_exiting_ty, Inv_exclusivity, Inv_enter_ctr, Inv_stay_ctr, Inv_exit_ctr, Inv_glueing, _ML2BR, GRD_ML2BR, ACT_ML2BR, ML2BR

THEOREM PO_Next_BR2ML_glueing == Invariant /\ Inv_entering_ty' /\ Inv_islecars_ty' /\ Inv_exiting_ty' /\ Inv_exclusivity' /\ Inv_enter_ctr' /\ Inv_stay_ctr' /\ Inv_exit_ctr' /\ _BR2ML => Inv_glueing'
PROOF
BY DEF Invariant, Inv_entering_ty, Inv_islecars_ty, Inv_exiting_ty, Inv_exclusivity, Inv_enter_ctr, Inv_stay_ctr, Inv_exit_ctr, Inv_glueing, _BR2ML, GRD_BR2ML, ACT_BR2ML, BR2ML

THEOREM PO_Next_BR2IL_glueing == Invariant /\ Inv_entering_ty' /\ Inv_islecars_ty' /\ Inv_exiting_ty' /\ Inv_exclusivity' /\ Inv_enter_ctr' /\ Inv_stay_ctr' /\ Inv_exit_ctr' /\ _BR2IL => Inv_glueing'
PROOF
BY DEF Invariant, Inv_entering_ty, Inv_islecars_ty, Inv_exiting_ty, Inv_exclusivity, Inv_enter_ctr, Inv_stay_ctr, Inv_exit_ctr, Inv_glueing, _BR2IL, GRD_BR2IL, ACT_BR2IL, BR2IL

THEOREM PO_Next_IL2BR_glueing == Invariant /\ Inv_entering_ty' /\ Inv_islecars_ty' /\ Inv_exiting_ty' /\ Inv_exclusivity' /\ Inv_enter_ctr' /\ Inv_stay_ctr' /\ Inv_exit_ctr' /\ _IL2BR => Inv_glueing'
PROOF
BY DEF Invariant, Inv_entering_ty, Inv_islecars_ty, Inv_exiting_ty, Inv_exclusivity, Inv_enter_ctr, Inv_stay_ctr, Inv_exit_ctr, Inv_glueing, _IL2BR, GRD_IL2BR, ACT_IL2BR, IL2BR

THEOREM PO_Init_glueing == Init => Inv_glueing
PROOF
BY DEF Init, Inv_glueing

THEOREM PO_Next_glueing == Invariant /\ Next /\ Inv_entering_ty' /\ Inv_islecars_ty' /\ Inv_exiting_ty' /\ Inv_exclusivity' /\ Inv_enter_ctr' /\ Inv_stay_ctr' /\ Inv_exit_ctr' => Inv_glueing'
PROOF
BY THEOREM PO_Next_ML2BR_glueing, THEOREM PO_Next_BR2ML_glueing, THEOREM PO_Next_BR2IL_glueing, THEOREM PO_Next_IL2BR_glueing DEF Next


THEOREM InvariantIsPreserved == Invariant /\ Next => Invariant'
PROOF
BY THEOREM PO_Next_entering_ty, THEOREM PO_Next_islecars_ty, THEOREM PO_Next_exiting_ty, THEOREM PO_Next_exclusivity, THEOREM PO_Next_enter_ctr, THEOREM PO_Next_stay_ctr, THEOREM PO_Next_exit_ctr, THEOREM PO_Next_glueing DEF Invariant

THEOREM NoDeadlock == Invariant => 
	\/ GRD_ML2BR
	\/ GRD_BR2ML
	\/ GRD_BR2IL
	\/ GRD_IL2BR
PROOF
	BY DEF GRD_ML2BR,GRD_BR2ML,GRD_BR2IL,GRD_IL2BR, Invariant,Inv_entering_ty,Inv_islecars_ty,Inv_exiting_ty,Inv_exclusivity,Inv_enter_ctr,Inv_stay_ctr,Inv_exit_ctr,Inv_glueing
========================================
