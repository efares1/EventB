let m2_BridgeToIsle = {
	name = "m2_BridgeToIsle";
	refines = [m1_IsleCapacity];
	sees = [];
	variables = ["entering"; "islecars"; "exiting"; "cars"];
	invariants = [{name = "entering_ty"; predicate =  entering ∈ ℤ}
	; {name = "islecars_ty"; predicate =  islecars ∈ ℤ}
	; {name = "exiting_ty"; predicate =  exiting ∈ ℤ}
	; {name = "exclusivity"; predicate =   entering = 0 ∨ exiting = 0}
	; {name = "enter_ctr"; predicate =   entering ≥ 0}
	; {name = "stay_ctr"; predicate =   islecars ≥ 0}
	; {name = "exit_ctr"; predicate =   exiting ≥ 0}
	; {name = "glueing"; predicate =   cars = entering + islecars + exiting}
	];
	events = [{
		name = "INITIALISATION";
		refinements = [];
		parameters = [];
		guards = [];
		witness = [];
		action = [{name = "entering"; action = {left = ["entering"]; right = [ 0]}
		}
		;{name = "islecars"; action = {left = ["islecars"]; right = [ 0]}
		}
		;{name = "exiting"; action = {left = ["exiting"]; right = [ 0]}
		}
		]
	}
	; {
		name = "ML2BR";
		refinements = [];
		parameters = [];
		guards = [{name = "exclusivity"; predicate =  exiting=0}
		];
		witness = [];
		action = [{name = "entering"; action = {left = ["entering"]; right = [ entering+1]}
		}
		]
	}
	; {
		name = "BR2ML";
		refinements = [];
		parameters = [];
		guards = [{name = "exclusivity"; predicate =  entering=0∨exiting − 1=0}
		;{name = "exit_ctr"; predicate =  exiting − 1≥0}
		];
		witness = [];
		action = [{name = "exiting"; action = {left = ["exiting"]; right = [ exiting−1]}
		}
		]
	}
	; {
		name = "BR2IL";
		refinements = [];
		parameters = [];
		guards = [{name = "exclusivity"; predicate =  entering − 1=0∨exiting=0}
		;{name = "enter_ctr"; predicate =  entering − 1≥0}
		];
		witness = [];
		action = [{name = "islecars"; action = {left = ["islecars"]; right = [ islecars+1]}
		}
		;{name = "entering"; action = {left = ["entering"]; right = [ entering−1]}
		}
		]
	}
	; {
		name = "IL2BR";
		refinements = [];
		parameters = [];
		guards = [{name = "exclusivity"; predicate =  entering=0}
		;{name = "stay_ctr"; predicate =  islecars − 1≥0}
		];
		witness = [];
		action = [{name = "exiting"; action = {left = ["exiting"]; right = [ exiting+1]}
		}
		;{name = "islecars"; action = {left = ["islecars"]; right = [ islecars−1]}
		}
		]
	}
	]
}
