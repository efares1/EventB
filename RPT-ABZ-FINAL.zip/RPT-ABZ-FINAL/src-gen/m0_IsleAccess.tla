(*
machine m0_IsleAccess
events
  event INITIALISATION end
  event ML2BR end
  event BR2ML end
end
*)
------- MODULE m0_IsleAccess -------
EXTENDS Integers, TLAPS
VARIABLES
	event
vars == <<event>>

Invariant ==

Init == 
	/\ event = <<"INITIALISATION">>
ML2BR  == event = <<"ML2BR">>
GRD_ML2BR ==
ACT_ML2BR ==
_ML2BR  ==
	/\ ML2BR'
	/\ GRD_ML2BR
	/\ ACT_ML2BR
BR2ML  == event = <<"BR2ML">>
GRD_BR2ML ==
ACT_BR2ML ==
_BR2ML  ==
	/\ BR2ML'
	/\ GRD_BR2ML
	/\ ACT_BR2ML

Next ==
	\/ _ML2BR
	\/ _BR2ML

Spec == Init /\ [][Next]_vars

THEOREM InvariantIsPreserved == Invariant /\ Next => Invariant'
PROOF
BY  DEF Invariant

THEOREM NoDeadlock == Invariant => 
	\/ GRD_ML2BR
	\/ GRD_BR2ML
PROOF
	BY DEF GRD_ML2BR,GRD_BR2ML, Invariant,
========================================
